import React from 'react';

export default function About() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-playfair font-bold text-center mb-2">About Luxe Queer</h2>
        <div className="w-24 h-1 bg-accent mx-auto mb-8"></div>
        <p className="text-xl font-montserrat text-center max-w-4xl mx-auto mb-16">
          Luxe Queer is not just a magazine—it's a revolution in luxury publishing. We exist at the powerful intersection of opulence and authenticity, where queer perspectives don't just influence luxury—they redefine it.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="bg-gray-50 p-8 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <h3 className="text-2xl font-playfair font-bold mb-4">Our Vision</h3>
            <p className="font-montserrat text-gray-700">
              Our pages showcase fashion, art, culture, travel, technology, and luxury through a distinctly queer lens, creating a publication as multifaceted and brilliant as our community.
            </p>
          </div>
          
          <div className="bg-gray-50 p-8 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <h3 className="text-2xl font-playfair font-bold mb-4">Our Voice</h3>
            <p className="font-montserrat text-gray-700">
              Led by our editorial persona Octavia Opulence³, we deliver content that is unapologetically bold yet refined, challenging conventional luxury paradigms while maintaining elevated standards.
            </p>
          </div>
          
          <div className="bg-gray-50 p-8 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <h3 className="text-2xl font-playfair font-bold mb-4">Our Mark</h3>
            <p className="font-montserrat text-gray-700">
              Our signature blue lipstick serves as a visual reminder that luxury, in our hands, will never be conventional. It's our promise to deliver content that makes a statement.
            </p>
          </div>
          
          <div className="bg-gray-50 p-8 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <h3 className="text-2xl font-playfair font-bold mb-4">Our Innovation</h3>
            <p className="font-montserrat text-gray-700">
              Through innovative technology, including our NVIDIA-powered digital human ambassador, we're creating a media experience that's as forward-thinking as our audience.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
