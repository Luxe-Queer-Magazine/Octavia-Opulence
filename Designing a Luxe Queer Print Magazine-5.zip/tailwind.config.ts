import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        playfair: ["Playfair Display", "serif"],
        montserrat: ["Montserrat", "sans-serif"],
      },
      colors: {
        primary: "var(--primary-color)",
        secondary: "var(--secondary-color)",
        accent: "var(--accent-color)",
        "accent-dark": "var(--accent-dark)",
        "text-color": "var(--text-color)",
        "light-gray": "var(--light-gray)",
        "dark-gray": "var(--dark-gray)",
      },
      backgroundImage: {
        "gradient-blue": "linear-gradient(to bottom, #0a2151, #1a3a7a)",
      },
    },
  },
  plugins: [],
};

export default config;
