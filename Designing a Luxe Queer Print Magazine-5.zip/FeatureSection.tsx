import React from 'react';
import Image from 'next/image';

type FeatureProps = {
  title: string;
  description: string;
  imageSrc: string;
  imageAlt: string;
  buttonText: string;
  buttonLink: string;
};

export default function FeatureSection({ 
  title, 
  description, 
  imageSrc, 
  imageAlt,
  buttonText,
  buttonLink
}: FeatureProps) {
  return (
    <div className="relative h-[500px] overflow-hidden my-16">
      {/* Background image */}
      <div className="absolute inset-0 z-0">
        <Image
          src={imageSrc}
          alt={imageAlt}
          fill
          style={{ objectFit: 'cover' }}
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[rgba(0,0,0,0.7)] to-[rgba(0,0,0,0.3)] z-10"></div>
      </div>
      
      {/* Content */}
      <div className="relative z-20 h-full flex items-center">
        <div className="p-16 max-w-[600px] text-white">
          <h2 className="text-4xl font-playfair font-bold mb-4 drop-shadow-md">{title}</h2>
          <p className="text-lg font-montserrat mb-8 drop-shadow-md">{description}</p>
          <a 
            href={buttonLink} 
            className="inline-block bg-accent hover:bg-accent-dark text-white font-montserrat font-bold py-3 px-6 rounded transition-colors"
          >
            {buttonText}
          </a>
        </div>
      </div>
    </div>
  );
}
