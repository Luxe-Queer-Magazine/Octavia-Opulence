import Link from 'next/link';
import Image from 'next/image';

export default function Header() {
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <h1 className="text-3xl font-playfair font-bold tracking-tight">LUXE QUEER</h1>
          <div className="relative ml-2">
            <Image 
              src="/images/blue_lipstick_kiss_logo.jpg" 
              alt="Blue lipstick kiss logo" 
              width={40} 
              height={30} 
              className="object-contain"
            />
          </div>
        </div>
        <nav>
          <ul className="flex space-x-8">
            <li><Link href="#about" className="font-montserrat text-primary hover:text-accent transition-colors">ABOUT</Link></li>
            <li><Link href="#features" className="font-montserrat text-primary hover:text-accent transition-colors">FEATURES</Link></li>
            <li><Link href="#octavia" className="font-montserrat text-primary hover:text-accent transition-colors">OCTAVIA</Link></li>
            <li><Link href="#subscribe" className="font-montserrat text-primary hover:text-accent transition-colors">SUBSCRIBE</Link></li>
          </ul>
        </nav>
      </div>
    </header>
  );
}
