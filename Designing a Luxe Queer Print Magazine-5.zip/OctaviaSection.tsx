import React from 'react';
import OctaviaCard from '../ui/OctaviaCard';

export default function OctaviaSection() {
  const octaviaTraits = [
    {
      title: "Elegance & Style",
      description: "Octavia's fashion sense is a blend of sophistication and boldness, reflecting her journey and the influences of her travels. She incorporates cultural motifs and vibrant colors into her outfits, making her a style icon who transcends conventional luxury."
    },
    {
      title: "Resilience & Empowerment",
      description: "Her story of overcoming adversity and finding herself on the runway highlights her strength and determination. She serves as an inspiration to others, showing that one can achieve greatness despite obstacles, embodying the transformative power of authenticity."
    },
    {
      title: "Global Influence",
      description: "As a travel maven, Octavia's experiences shape her worldview and style. She connects with diverse communities, fostering understanding and appreciation for different cultures, bringing a global perspective to luxury that transcends borders and conventions."
    },
    {
      title: "Advocacy & Activism",
      description: "Octavia uses her platform to advocate for inclusivity and acceptance. She challenges societal norms and fights for the rights of marginalized communities, embodying the spirit of activists like Marsha P. Johnson and Sylvia Rivera while maintaining her luxury positioning."
    },
    {
      title: "Connection to Drag Culture",
      description: "Octavia has a soft spot for drag culture, appreciating its artistry and expression. She can engage with both gay men and lesbians, understanding the nuances of their experiences and advocating for their rights while celebrating the transformative power of performance."
    },
    {
      title: "Reading for Filth",
      description: "Like Elektra Abundance, Octavia possesses the ability to \"read\" others with wit and sharpness. This skill adds to her charisma and presence, making her a formidable figure in any setting while maintaining the sophisticated edge that defines Luxe Queer's editorial voice."
    }
  ];

  return (
    <section id="octavia" className="py-24 bg-gray-50 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-36 h-36 bg-accent opacity-10 rounded-bl-full"></div>
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-playfair font-bold mb-4 relative inline-block">
            Meet Octavia Opulence³
            <span className="absolute bottom-[-10px] left-1/2 transform -translate-x-1/2 w-20 h-1 bg-accent"></span>
          </h2>
          <p className="text-xl font-montserrat text-gray-600 max-w-3xl mx-auto">
            The embodiment of Luxe Queer's editorial vision, a multifaceted character who embodies elegance, resilience, and a global perspective.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {octaviaTraits.map((trait, index) => (
            <OctaviaCard 
              key={index}
              title={trait.title}
              description={trait.description}
            />
          ))}
        </div>
        
        <div className="bg-blue-50 border-l-4 border-accent p-8 max-w-3xl mx-auto relative">
          <div className="absolute top-[-20px] left-5 text-6xl font-serif text-accent opacity-30">"</div>
          <p className="text-xl font-montserrat italic text-gray-800 relative z-10 mb-4">
            "In a world of beige conformity, wear blue lipstick and make them remember you. True opulence is the freedom to be authentically, unapologetically yourself."
          </p>
          <cite className="block text-right font-playfair font-bold text-accent">— Octavia Opulence³</cite>
        </div>
      </div>
    </section>
  );
}
