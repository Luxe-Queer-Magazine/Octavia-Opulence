import React from 'react';
import FeatureCardWithImage from '../ui/FeatureCardWithImage';
import BlueLipstickEditCard from '../ui/BlueLipstickEditCard';

export default function FeaturesGridWithDarkBlueGradient() {
  return (
    <section className="container mx-auto px-4 py-16">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <FeatureCardWithImage
          title="Travel"
          description="Destinations that don't just welcome queer travelers—they celebrate them in opulent style."
          imageSrc="/images/features/luxury_yacht.jpg"
          imageAlt="Luxury travel destination"
          linkText="Read More"
          linkHref="/features/travel"
        />
        
        <FeatureCardWithImage
          title="Technology"
          description="Innovations that are reshaping our world with inclusivity and luxury at their core."
          imageSrc="/images/features/technology_model.jpg"
          imageAlt="Innovative technology"
          linkText="Read More"
          linkHref="/features/technology"
        />
        
        <BlueLipstickEditCard
          title="The Blue Lipstick Edit"
          description="Our signature series featuring Octavia's bold takes on luxury and queer culture."
        >
          <a 
            href="/features/blue-lipstick-edit" 
            className="inline-block font-montserrat font-semibold text-white hover:text-gray-200 transition-colors"
          >
            Read More
          </a>
        </BlueLipstickEditCard>
      </div>
    </section>
  );
}
