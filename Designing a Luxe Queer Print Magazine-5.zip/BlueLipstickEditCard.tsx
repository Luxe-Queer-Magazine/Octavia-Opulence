import React from 'react';
import Image from 'next/image';

type CardProps = {
  title: string;
  description: string;
  imageSrc?: string;
  imageAlt?: string;
  children?: React.ReactNode;
};

export default function BlueLipstickEditCard({ 
  title, 
  description, 
  imageSrc = '/images/features/blue_lipstick_kiss.jpg',
  imageAlt = 'Blue lipstick kiss mark', 
  children 
}: CardProps) {
  return (
    <div className="rounded-lg shadow-md overflow-hidden">
      <div className="bg-gradient-to-b from-[#0a2151] to-[#1a3a7a] text-white p-6">
        {imageSrc && (
          <div className="flex justify-center mb-4">
            <div className="relative w-32 h-32">
              <Image
                src={imageSrc}
                alt={imageAlt}
                fill
                style={{ objectFit: 'contain' }}
                className="opacity-90"
              />
            </div>
          </div>
        )}
        <h3 className="font-playfair text-xl font-bold mb-4">{title}</h3>
        <p className="font-montserrat">{description}</p>
        {children && <div className="mt-4">{children}</div>}
      </div>
    </div>
  );
}
