import React from 'react';

type QuoteProps = {
  quote: string;
  author: string;
};

export default function Quote({ quote, author }: QuoteProps) {
  return (
    <section className="py-16 bg-accent text-white">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl md:text-4xl font-playfair font-bold italic mb-4">
          "{quote}"
        </h2>
        <p className="text-xl font-montserrat">— {author}</p>
      </div>
    </section>
  );
}
