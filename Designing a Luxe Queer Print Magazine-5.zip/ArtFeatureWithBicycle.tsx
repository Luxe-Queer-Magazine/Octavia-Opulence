import React from 'react';
import Image from 'next/image';

export default function ArtFeatureWithBicycle() {
  return (
    <div className="relative h-[500px] overflow-hidden my-16">
      {/* Bicycle image background */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/bicycle.png"
          alt="Artistic bicycle with flower basket"
          fill
          style={{ objectFit: 'contain', backgroundColor: '#f8f9fa' }}
          priority
        />
      </div>
      
      {/* Content overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-[rgba(0,0,0,0.7)] to-[rgba(0,0,0,0.3)] z-10"></div>
      
      {/* Text content */}
      <div className="relative z-20 h-full flex items-center">
        <div className="p-16 max-w-[600px] text-white">
          <h2 className="text-4xl font-playfair font-bold mb-4 drop-shadow-md">Art & Culture</h2>
          <p className="text-lg font-montserrat mb-8 drop-shadow-md">
            Spotlighting visionaries who transform cultural landscapes through a queer perspective. 
            Our vibrant coverage celebrates the artists and creators who challenge conventions and 
            redefine cultural expression.
          </p>
          <a 
            href="/features/art-culture" 
            className="inline-block bg-accent hover:bg-accent-dark text-white font-montserrat font-bold py-3 px-6 rounded transition-colors"
          >
            Explore Art & Culture
          </a>
        </div>
      </div>
    </div>
  );
}
