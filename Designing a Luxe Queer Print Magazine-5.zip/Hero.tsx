import React from 'react';

export default function Hero() {
  return (
    <section className="relative h-screen bg-primary overflow-hidden">
      <div className="absolute inset-0 z-0">
        {/* Blue lipstick hero image */}
        <div className="w-full h-full bg-blue-900"></div>
      </div>
      <div className="relative z-10 h-full flex items-center">
        <div className="container mx-auto px-4 text-white">
          <h2 className="text-5xl md:text-6xl font-playfair font-bold mb-4">Luxury Redefined</h2>
          <p className="text-xl md:text-2xl font-montserrat mb-8">Where queer brilliance meets luxury, and neither will ever be the same.</p>
          <div className="inline-block">
            <a 
              href="#subscribe" 
              className="bg-accent hover:bg-accent-dark text-white font-montserrat font-bold py-3 px-6 rounded transition-colors"
            >
              Experience Luxe Queer
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
