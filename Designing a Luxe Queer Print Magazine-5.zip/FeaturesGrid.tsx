import React from 'react';
import FeatureCard from '../ui/FeatureCard';

export default function FeaturesGrid() {
  return (
    <section className="container mx-auto px-4 py-16">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <FeatureCard
          title="Travel"
          description="Destinations that don't just welcome queer travelers—they celebrate them in opulent style."
          imageSrc="/images/travel.jpg"
          linkText="Read More"
          linkHref="/features/travel"
        />
        
        <FeatureCard
          title="Technology"
          description="Innovations that are reshaping our world with inclusivity and luxury at their core."
          imageSrc="/images/technology.jpg"
          linkText="Read More"
          linkHref="/features/technology"
        />
        
        <FeatureCard
          title="The Blue Lipstick Edit"
          description="Our signature series featuring Octavia's bold takes on luxury and queer culture."
          isBlueCard={true}
          linkText="Read More"
          linkHref="/features/blue-lipstick-edit"
        />
      </div>
    </section>
  );
}
