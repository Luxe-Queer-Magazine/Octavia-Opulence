import React from 'react';
import Image from 'next/image';

export default function HeroWithBlueLipstick() {
  return (
    <section className="relative h-screen overflow-hidden">
      {/* Blue lipstick hero image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/blue-lipstick-hero.jpg"
          alt="Blue lipstick close-up"
          fill
          priority
          style={{ objectFit: 'cover' }}
        />
      </div>
      
      <div className="relative z-10 h-full flex items-center">
        <div className="container mx-auto px-4 text-white">
          <h2 className="text-5xl md:text-6xl font-playfair font-bold mb-4 drop-shadow-lg">Luxury Redefined</h2>
          <p className="text-xl md:text-2xl font-montserrat mb-8 drop-shadow-md max-w-2xl">
            Where queer brilliance meets luxury, and neither will ever be the same.
          </p>
          <div className="inline-block">
            <a 
              href="#subscribe" 
              className="bg-accent hover:bg-accent-dark text-white font-montserrat font-bold py-3 px-6 rounded transition-colors"
            >
              Experience Luxe Queer
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
