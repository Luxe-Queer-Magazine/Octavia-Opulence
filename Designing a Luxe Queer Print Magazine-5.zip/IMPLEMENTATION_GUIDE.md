# Octavia Voice Model Implementation Guide

This guide provides step-by-step instructions for implementing the Octavia Voice model using the repository structure and scripts provided. Follow these instructions to set up, train, and deploy your own version of the Octavia Voice model for Luxe Queer magazine.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Repository Setup](#repository-setup)
3. [Training Process](#training-process)
4. [Evaluation](#evaluation)
5. [Inference and Deployment](#inference-and-deployment)
6. [Integration with Meta API](#integration-with-meta-api)
7. [Troubleshooting](#troubleshooting)

## Prerequisites

Before beginning, ensure you have:

- A Hugging Face account with organization set up
- Access to GPU resources for training (recommended: A100 or equivalent)
- Python 3.8+ installed
- Git LFS installed (for handling large model files)

Required Python packages:
```bash
pip install transformers==4.38.0 peft==0.7.0 accelerate==0.25.0 bitsandbytes==0.41.0 datasets==2.16.0 evaluate==0.4.1 rouge_score==0.1.2 tensorboard==2.15.1 pandas==2.1.0
```

## Repository Setup

### 1. Clone the Repository Template

First, upload the provided repository structure to your Hugging Face account:

1. Log in to Hugging Face and navigate to your organization page
2. Click "New" to create a new model repository
3. Name it "Octavia-Voice" and set it to private
4. Initialize with the provided README.md file
5. Upload all files from the repository structure

Alternatively, you can use Git:

```bash
# Clone the empty repository
git clone https://huggingface.co/LuxeQueer/Octavia-Voice

# Copy all files from the template
cp -r /path/to/octavia_voice_repo/* /path/to/Octavia-Voice/

# Push to Hugging Face
cd /path/to/Octavia-Voice
git add .
git commit -m "Initial repository setup"
git push
```

### 2. Set Up Training Data

The repository already includes training data in the `data` directory:

- `octavia_style_guide.md`: Comprehensive guide to Octavia's voice
- `octavia_voice_examples.jsonl`: Training examples in the required format
- `octavia_voice_validation.jsonl`: Validation examples for evaluation

If you want to add more training examples:

1. Create additional examples following the format in the existing files
2. Use the `prepare_dataset.py` script to process and format your data:

```bash
python scripts/prepare_dataset.py \
  --input_file your_new_examples.csv \
  --output_file data/additional_examples.jsonl \
  --instruction_column "prompt" \
  --input_column "context" \
  --output_column "response" \
  --create_validation
```

## Training Process

### 1. Select Base Model

The repository is configured to use Mistral-7B-Instruct as the base model, but you can choose from:

- `mistralai/Mistral-7B-Instruct-v0.2` (recommended for starting)
- `google/gemma-7b-it` (alternative option)
- `mistralai/Mistral-Small-3.1-24B-Instruct-2503` (for production quality)

Larger models will require more GPU resources but may produce better results.

### 2. Run Training

Execute the training script:

```bash
python scripts/train.py \
  --base_model mistralai/Mistral-7B-Instruct-v0.2 \
  --data_path data/octavia_voice_examples.jsonl \
  --eval_data_path data/octavia_voice_validation.jsonl \
  --output_dir models/adapter_model \
  --config_path configs/training_config.json
```

Training parameters can be adjusted in `configs/training_config.json`. The default configuration:
- Uses LoRA fine-tuning with r=16, alpha=32
- Trains for 3 epochs with learning rate 2e-5
- Uses 4-bit quantization to reduce memory requirements
- Evaluates and saves checkpoints every 500 steps

### 3. Monitor Training

Training progress can be monitored using TensorBoard:

```bash
tensorboard --logdir models/adapter_model
```

Key metrics to watch:
- Training loss: Should steadily decrease
- Validation loss: Should decrease without diverging from training loss
- Learning rate: Should follow the warmup and decay schedule

## Evaluation

After training, evaluate the model's performance:

```bash
python scripts/evaluate.py \
  --base_model mistralai/Mistral-7B-Instruct-v0.2 \
  --adapter_model models/adapter_model \
  --eval_data data/octavia_voice_validation.jsonl \
  --output_dir evaluation_results
```

This will generate a detailed evaluation report with:
- BERTScore metrics for semantic similarity
- ROUGE metrics for text overlap
- Sample-by-sample comparisons of generated vs. reference text

A successful model should achieve:
- BERTScore F1 > 0.85
- ROUGE-L F1 > 0.4

## Inference and Deployment

### 1. Test the Model

Generate text with your fine-tuned model:

```bash
python scripts/inference.py \
  --base_model mistralai/Mistral-7B-Instruct-v0.2 \
  --adapter_model models/adapter_model \
  --prompt "Write a fashion review for Luxe Queer magazine" \
  --input "Review the latest collection from Prada which features gender-neutral designs and sustainable materials." \
  --config_path configs/generation_config.json
```

### 2. Merge Adapter Weights (Optional)

For deployment efficiency, you can merge the LoRA adapter weights back into the base model:

```bash
python scripts/merge_lora.py \
  --base_model mistralai/Mistral-7B-Instruct-v0.2 \
  --adapter_model models/adapter_model \
  --output_dir models/merged_model \
  --half
```

### 3. Push to Hugging Face

Upload your trained model to Hugging Face:

```bash
# For adapter-only model
huggingface-cli upload LuxeQueer/Octavia-Voice models/adapter_model

# For merged model
huggingface-cli upload LuxeQueer/Octavia-Voice-Full models/merged_model
```

### 4. Create a Demo Space

Create a Hugging Face Space to showcase your model:

1. Go to huggingface.co and click "New Space"
2. Choose "Gradio" as the SDK
3. Create an app.py file with the following code:

```python
import gradio as gr
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, GenerationConfig
from peft import PeftModel

# Load model and tokenizer
base_model = "mistralai/Mistral-7B-Instruct-v0.2"
adapter_model = "LuxeQueer/Octavia-Voice"

tokenizer = AutoTokenizer.from_pretrained(base_model)
model = AutoModelForCausalLM.from_pretrained(
    base_model,
    torch_dtype=torch.float16,
    device_map="auto"
)
model = PeftModel.from_pretrained(model, adapter_model)

def format_prompt(instruction, input_text=None):
    if input_text:
        return f"### Instruction:\n{instruction}\n\n### Input:\n{input_text}\n\n### Response:\n"
    else:
        return f"### Instruction:\n{instruction}\n\n### Response:\n"

def generate(instruction, input_text="", temperature=0.7, max_length=1024):
    prompt = format_prompt(instruction, input_text if input_text else None)
    
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    
    generation_config = GenerationConfig(
        temperature=temperature,
        top_p=0.9,
        top_k=50,
        max_new_tokens=max_length,
        repetition_penalty=1.1,
    )
    
    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            generation_config=generation_config,
        )
    
    response = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return response[len(prompt):]

# Create Gradio interface
with gr.Blocks(css="footer {visibility: hidden}") as demo:
    gr.Markdown("# Octavia Voice - Luxe Queer Magazine")
    gr.Markdown("Generate content in the distinctive voice of Octavia Opulence³, the editorial persona of Luxe Queer magazine.")
    
    with gr.Row():
        with gr.Column():
            instruction = gr.Textbox(label="Instruction", placeholder="Write a fashion review for Luxe Queer magazine")
            input_text = gr.Textbox(label="Input (Optional)", placeholder="Review the latest collection from Prada...")
            temperature = gr.Slider(minimum=0.1, maximum=1.5, value=0.7, step=0.1, label="Temperature")
            max_length = gr.Slider(minimum=64, maximum=4096, value=1024, step=64, label="Maximum Length")
            submit_btn = gr.Button("Generate")
        
        with gr.Column():
            output = gr.Textbox(label="Octavia's Response", lines=20)
    
    submit_btn.click(
        generate,
        inputs=[instruction, input_text, temperature, max_length],
        outputs=output
    )
    
    gr.Markdown("## Example Instructions")
    gr.Markdown("""
    - Write an editor's letter for the summer issue of Luxe Queer magazine
    - Write a review of a luxury hotel in Paris that claims to be LGBTQ+ friendly
    - Write a response to a reader's letter about breaking into the luxury fashion industry
    - Write a piece for The Blue Lipstick Edit about luxury brands' Pride campaigns
    """)

demo.launch()
```

## Integration with Meta API

To integrate the Octavia Voice model with your Meta social media accounts:

### 1. Set Up API Access

Create a middleware service that connects your Hugging Face model to the Meta Graph API:

1. Set up a server with Flask or FastAPI
2. Create endpoints that accept content requests
3. Use the Hugging Face Inference API to generate content
4. Post content to Meta platforms using the Graph API

Example middleware code:

```python
from flask import Flask, request, jsonify
import requests
import json
import os

app = Flask(__name__)

HF_API_TOKEN = os.environ.get("HF_API_TOKEN")
META_ACCESS_TOKEN = os.environ.get("META_ACCESS_TOKEN")
HF_MODEL = "LuxeQueer/Octavia-Voice"

@app.route('/generate_post', methods=['POST'])
def generate_post():
    data = request.json
    topic = data.get('topic', '')
    context = data.get('context', '')
    platform = data.get('platform', 'facebook')
    
    # Generate content using Hugging Face API
    content = generate_content(topic, context, platform)
    
    # Post to Meta platform
    if platform == 'facebook':
        post_id = post_to_facebook(content)
    elif platform == 'instagram':
        post_id = post_to_instagram(content)
    
    return jsonify({
        'content': content,
        'post_id': post_id
    })

def generate_content(topic, context, platform):
    # Format based on platform
    if platform == 'facebook':
        instruction = f"Write a Facebook post for Luxe Queer magazine about {topic}"
    elif platform == 'instagram':
        instruction = f"Write an Instagram caption for Luxe Queer magazine about {topic}"
    
    # Call Hugging Face Inference API
    payload = {
        "inputs": f"### Instruction:\n{instruction}\n\n### Input:\n{context}\n\n### Response:\n",
        "parameters": {
            "temperature": 0.7,
            "max_new_tokens": 500,
            "top_p": 0.9
        }
    }
    
    headers = {
        "Authorization": f"Bearer {HF_API_TOKEN}",
        "Content-Type": "application/json"
    }
    
    response = requests.post(
        f"https://api-inference.huggingface.co/models/{HF_MODEL}",
        headers=headers,
        json=payload
    )
    
    result = response.json()
    return result[0]['generated_text'].split("### Response:\n")[1]

def post_to_facebook(content):
    url = f"https://graph.facebook.com/v18.0/me/feed"
    payload = {
        "message": content,
        "access_token": META_ACCESS_TOKEN
    }
    response = requests.post(url, data=payload)
    return response.json().get('id')

def post_to_instagram(content):
    # Instagram requires a media object first
    # This is simplified - actual implementation would need image handling
    url = f"https://graph.facebook.com/v18.0/me/media"
    payload = {
        "caption": content,
        "access_token": META_ACCESS_TOKEN
    }
    response = requests.post(url, data=payload)
    return response.json().get('id')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
```

### 2. Schedule Content Generation

Set up a content calendar system that triggers the middleware:

1. Create a database of content topics and schedules
2. Set up a cron job or scheduler to trigger content generation
3. Implement approval workflows for human review before posting

## Troubleshooting

### Common Issues

1. **Out of Memory Errors**
   - Use a smaller batch size in training_config.json
   - Enable gradient accumulation (increase gradient_accumulation_steps)
   - Use 4-bit quantization (enabled by default)

2. **Poor Generation Quality**
   - Increase training epochs
   - Add more diverse training examples
   - Try a larger base model
   - Adjust generation parameters (temperature, top_p)

3. **Slow Training**
   - Use a more powerful GPU
   - Reduce model size
   - Optimize LoRA parameters (reduce r value)

4. **Deployment Issues**
   - Check Hugging Face API token permissions
   - Verify model visibility settings
   - Test with the Inference API before full integration

### Getting Help

If you encounter issues not covered in this guide:

1. Check the Hugging Face forums
2. Review PEFT and Transformers documentation
3. Contact the Luxe Queer AI team at ai@luxequeer.com

## Next Steps

After successfully implementing the Octavia Voice model:

1. Continuously improve the model by adding more training examples
2. Implement A/B testing to refine generation parameters
3. Expand to other content types beyond those in the initial training data
4. Consider fine-tuning specialized versions for different content categories
5. Integrate with other platforms beyond Meta (Twitter, LinkedIn, etc.)

---

This implementation guide provides a comprehensive framework for deploying the Octavia Voice model. By following these steps, you'll create a sophisticated AI system that embodies the distinctive voice of Octavia Opulence³ across all your digital platforms.
