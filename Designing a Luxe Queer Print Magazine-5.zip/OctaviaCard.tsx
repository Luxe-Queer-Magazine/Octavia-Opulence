import React from 'react';

type OctaviaCardProps = {
  title: string;
  description: string;
};

export default function OctaviaCard({ title, description }: OctaviaCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:-translate-y-1 hover:shadow-lg">
      <div className="bg-accent text-white p-6">
        <h3 className="font-playfair text-xl font-bold">{title}</h3>
      </div>
      <div className="p-6">
        <p className="font-montserrat text-gray-700">{description}</p>
      </div>
    </div>
  );
}
