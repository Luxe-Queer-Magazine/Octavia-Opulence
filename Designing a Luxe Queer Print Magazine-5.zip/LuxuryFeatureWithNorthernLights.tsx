import React from 'react';
import Image from 'next/image';

export default function LuxuryFeatureWithNorthernLights() {
  return (
    <div className="relative h-[500px] overflow-hidden my-16">
      {/* Northern lights image background */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/northern_lights.jpeg"
          alt="Northern lights in a majestic landscape"
          fill
          style={{ objectFit: 'cover' }}
          priority
        />
      </div>
      
      {/* Content overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-[rgba(0,0,0,0.7)] to-[rgba(0,0,0,0.3)] z-10"></div>
      
      {/* Text content */}
      <div className="relative z-20 h-full flex items-center">
        <div className="p-16 max-w-[600px] text-white">
          <h2 className="text-4xl font-playfair font-bold mb-4 drop-shadow-md">Luxury</h2>
          <p className="text-lg font-montserrat mb-8 drop-shadow-md">
            Redefining opulence through authenticity, sustainability, and queer excellence. 
            Our luxury coverage examines the evolving definition of opulence in a world that 
            demands both beauty and meaning.
          </p>
          <a 
            href="/features/luxury" 
            className="inline-block bg-accent hover:bg-accent-dark text-white font-montserrat font-bold py-3 px-6 rounded transition-colors"
          >
            Explore Luxury
          </a>
        </div>
      </div>
    </div>
  );
}
