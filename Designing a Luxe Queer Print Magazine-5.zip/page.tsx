import React from 'react';
import Header from '../components/layout/Header';
import HeroWithBlueLipstick from '../components/sections/HeroWithBlueLipstick';
import About from '../components/sections/About';
import Quote from '../components/ui/Quote';
import ArtFeatureWithBicycle from '../components/sections/ArtFeatureWithBicycle';
import LuxuryFeatureWithNorthernLights from '../components/sections/LuxuryFeatureWithNorthernLights';
import FeaturesGridWithDarkBlueGradient from '../components/sections/FeaturesGridWithDarkBlueGradient';
import OctaviaSection from '../components/sections/OctaviaSection';
import FadeInSection from '../components/animations/FadeInSection';
import ResponsiveContainer from '../components/layout/ResponsiveContainer';

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <Header />
      
      <HeroWithBlueLipstick />
      
      <FadeInSection>
        <About />
      </FadeInSection>
      
      <FadeInSection delay={200}>
        <Quote 
          quote="Darling, luxury isn't what you have—it's how completely you own who you are."
          author="Octavia Opulence³"
        />
      </FadeInSection>
      
      <ResponsiveContainer>
        <FadeInSection delay={300}>
          <h2 className="text-4xl text-center mt-16 mb-2">Featured Content</h2>
          <div className="blue-lipstick-accent"></div>
        </FadeInSection>
      </ResponsiveContainer>
      
      <FadeInSection delay={400}>
        <ArtFeatureWithBicycle />
      </FadeInSection>
      
      <FadeInSection delay={500}>
        <LuxuryFeatureWithNorthernLights />
      </FadeInSection>
      
      <FadeInSection delay={600}>
        <FeaturesGridWithDarkBlueGradient />
      </FadeInSection>
      
      <FadeInSection delay={700}>
        <OctaviaSection />
      </FadeInSection>
      
      <footer className="bg-primary text-white py-8 mt-16">
        <ResponsiveContainer>
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h3 className="text-2xl font-playfair">LUXE QUEER</h3>
              <p className="text-sm">Where queer brilliance meets luxury</p>
            </div>
            <div>
              <p>&copy; {new Date().getFullYear()} Luxe Queer Magazine. All rights reserved.</p>
            </div>
          </div>
        </ResponsiveContainer>
      </footer>
    </div>
  );
}
