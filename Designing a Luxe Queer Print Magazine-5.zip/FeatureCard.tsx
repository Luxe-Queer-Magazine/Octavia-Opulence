import React from 'react';
import Image from 'next/image';

type FeatureCardProps = {
  title: string;
  description: string;
  imageSrc?: string;
  isBlueCard?: boolean;
  linkText: string;
  linkHref: string;
};

export default function FeatureCard({ 
  title, 
  description, 
  imageSrc, 
  isBlueCard = false,
  linkText,
  linkHref
}: FeatureCardProps) {
  return (
    <div className={`feature-card rounded-lg shadow-md overflow-hidden ${isBlueCard ? 'bg-gradient-to-b from-accent to-accent-dark text-white' : 'bg-white'}`}>
      {imageSrc && (
        <div className="relative h-48 w-full">
          <Image
            src={imageSrc}
            alt={title}
            fill
            style={{ objectFit: 'cover' }}
          />
        </div>
      )}
      <div className="p-6">
        <h3 className="text-xl font-playfair font-bold mb-2">{title}</h3>
        <p className="font-montserrat mb-4">{description}</p>
        <a 
          href={linkHref} 
          className={`inline-block font-montserrat font-semibold transition-colors ${isBlueCard ? 'text-white hover:text-gray-200' : 'text-accent hover:text-accent-dark'}`}
        >
          {linkText}
        </a>
      </div>
    </div>
  );
}
