import React from 'react';

type CardProps = {
  title: string;
  description: string;
  children?: React.ReactNode;
};

export default function DarkBlueGradientCard({ title, description, children }: CardProps) {
  return (
    <div className="rounded-lg shadow-md overflow-hidden">
      <div className="bg-gradient-to-b from-[#0a2151] to-[#1a3a7a] text-white p-6">
        <h3 className="font-playfair text-xl font-bold mb-4">{title}</h3>
        <p className="font-montserrat">{description}</p>
        {children && <div className="mt-4">{children}</div>}
      </div>
    </div>
  );
}
