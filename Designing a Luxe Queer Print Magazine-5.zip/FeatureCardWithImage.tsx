import React from 'react';
import DarkBlueGradientCard from './DarkBlueGradientCard';
import Image from 'next/image';

type FeatureCardWithImageProps = {
  title: string;
  description: string;
  imageSrc: string;
  imageAlt: string;
  linkText: string;
  linkHref: string;
};

export default function FeatureCardWithImage({ 
  title, 
  description, 
  imageSrc, 
  imageAlt,
  linkText,
  linkHref
}: FeatureCardWithImageProps) {
  return (
    <div className="rounded-lg shadow-md overflow-hidden">
      <div className="relative h-48">
        <Image
          src={imageSrc}
          alt={imageAlt}
          fill
          style={{ objectFit: 'cover' }}
        />
      </div>
      <div className="bg-gradient-to-b from-[#0a2151] to-[#1a3a7a] text-white p-6">
        <h3 className="font-playfair text-xl font-bold mb-4">{title}</h3>
        <p className="font-montserrat mb-4">{description}</p>
        <a 
          href={linkHref} 
          className="inline-block font-montserrat font-semibold text-white hover:text-gray-200 transition-colors"
        >
          {linkText}
        </a>
      </div>
    </div>
  );
}
