import React from 'react';

export default function AnimatedCard({ children }: { children: React.ReactNode }) {
  return (
    <div className="transform transition-all duration-300 hover:scale-105 hover:shadow-xl">
      {children}
    </div>
  );
}
