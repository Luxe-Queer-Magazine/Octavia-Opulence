// Update all HTML files to include hamburger menu
const fs = require('fs');
const path = require('path');

// Configuration
const websiteDir = '/home/ubuntu/luxe_queer_website';

// Hamburger menu HTML to insert
const hamburgerMenuHTML = `
    <!-- Hamburger Menu Button -->
    <button class="hamburger-menu" aria-label="Toggle navigation menu" aria-expanded="false">
      <div class="hamburger-line"></div>
      <div class="hamburger-line"></div>
      <div class="hamburger-line"></div>
    </button>
    
    <!-- Mobile Navigation -->
    <div class="mobile-nav">
      <ul>
        <li><a href="/pages/about.html">ABOUT</a></li>
        <li><a href="/pages/features.html">FEATURES</a></li>
        <li><a href="/pages/octavia.html">OCTAVIA</a></li>
        <li><a href="/pages/subscribe.html">SUBSCRIBE</a></li>
      </ul>
    </div>`;

// Get all HTML files
function getAllHtmlFiles(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  
  list.forEach(file => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    
    if (stat.isDirectory() && file !== 'node_modules' && file !== 'build') {
      results = results.concat(getAllHtmlFiles(filePath));
    } else if (file.endsWith('.html') && file !== 'footer-template.html') {
      results.push(filePath);
    }
  });
  
  return results;
}

const htmlFiles = getAllHtmlFiles(websiteDir);
console.log(`Found ${htmlFiles.length} HTML files to update with hamburger menu`);

// Update each HTML file
htmlFiles.forEach(filePath => {
  console.log(`Adding hamburger menu to ${filePath}`);
  
  // Read file content
  let content = fs.readFileSync(filePath, 'utf8');
  
  // Check if file already has hamburger menu
  if (content.includes('hamburger-menu')) {
    console.log(`Hamburger menu already exists in ${filePath}`);
    return;
  }
  
  // Add hamburger menu after the nav element
  const navRegex = /<\/nav>/;
  if (navRegex.test(content)) {
    content = content.replace(navRegex, '</nav>' + hamburgerMenuHTML);
  } else {
    console.warn(`No nav element found in ${filePath}`);
  }
  
  // Add CSS link for hamburger menu
  if (!content.includes('hamburger-menu.css')) {
    const headEndRegex = /<\/head>/;
    const cssLink = `    <link rel="stylesheet" href="/css/hamburger-menu.css">\n</head>`;
    content = content.replace(headEndRegex, cssLink);
  }
  
  // Add JavaScript for hamburger menu
  if (!content.includes('hamburger-menu.js')) {
    const bodyEndRegex = /<\/body>/;
    const jsScript = `    <script src="/js/hamburger-menu.js"></script>\n</body>`;
    content = content.replace(bodyEndRegex, jsScript);
  }
  
  // Fix relative paths
  content = content.replace(/href="\/css\//g, 'href="../css/');
  content = content.replace(/src="\/js\//g, 'src="../js/');
  content = content.replace(/href="\/pages\//g, 'href="');
  
  // Write updated content back to file
  fs.writeFileSync(filePath, content);
});

console.log('All files updated successfully with hamburger menu');

// Update main CSS file to import hamburger-menu.css
const mainCssPath = path.join(websiteDir, 'css', 'styles.css');
let mainCss = fs.readFileSync(mainCssPath, 'utf8');

if (!mainCss.includes('@import "hamburger-menu.css"')) {
  mainCss = `@import "hamburger-menu.css";\n${mainCss}`;
  fs.writeFileSync(mainCssPath, mainCss);
  console.log('Updated main CSS file to import hamburger-menu.css');
}

// Update todo.md to reflect the hamburger menu fix
const todoPath = path.join('/home/ubuntu', 'todo.md');
if (fs.existsSync(todoPath)) {
  let todoContent = fs.readFileSync(todoPath, 'utf8');
  
  if (!todoContent.includes('Fix hamburger menu functionality')) {
    todoContent += '\n- [x] Fix hamburger menu functionality for mobile navigation\n';
    fs.writeFileSync(todoPath, todoContent);
    console.log('Updated todo.md with hamburger menu task');
  }
}

console.log('Hamburger menu implementation complete!');
