# Comprehensive Systems Access Guide for Luxe Queer Magazine

This document provides complete access information for all systems powering the Luxe Queer Magazine platform, including Supabase, n8n workflow automation, and other integrated services.

## Supabase Database & Authentication

### Instance Details
- **Supabase URL:** https://ovggshlfwumbtviwvbhi.supabase.co
- **Project Dashboard:** https://app.supabase.io/project/ovggshlfwumbtviwvbhi

### Authentication Credentials
```javascript
// Supabase client initialization
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://ovggshlfwumbtviwvbhi.supabase.co'
const supabaseKey = 'your-supabase-key' // Replace with actual key from dashboard
const supabase = createClient(supabaseUrl, supabaseKey)
```

### Database Schema
The database includes the following key tables:
- `profiles` - Extended user profile information
- `subscriptions` - Subscription details and status
- `subscription_tiers` - Tier definitions and features
- `transactions` - Payment and subscription change records
- `subscription_banks` - Fluid subscription banking records
- `subscription_pods` - Collective subscription pod configurations
- `pod_members` - Members of subscription pods
- `community_contributions` - Alternative subscription through contributions
- `events` - Exclusive events for higher-tier subscribers
- `nft_memberships` - Token-gated access records

### Access Instructions
1. Log in to the Supabase dashboard at https://app.supabase.io
2. Select the Luxe Queer Magazine project
3. Navigate to the SQL Editor to run queries or Table Editor to manage data
4. Use the Authentication section to manage users and authentication settings
5. API keys can be found in the API section

## n8n Workflow Automation

### Instance Details
- **n8n Dashboard:** http://your-n8n-instance-url (replace with actual URL)
- **API Endpoint:** http://your-n8n-instance-url/api/v1

### API Credentials
```
n8n API Key: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2ZjcyOGQ2YS0wMGUzLTQ4YTgtYTk2NS0zODBjZWIxYWNjYmQiLCJpc3MiOiJuOG4iLCJhdWQiOiJwdWJsaWMtYXBpIiwiaWF0IjoxNzQzODU1MDc1LCJleHAiOjE3NDY0MTc2MDB9.lhT_Q6hMnFZKEg0twL1WhLU3RF2YmEucyQhMiDkg7qY
```

### Implemented Workflows
1. **AI Content Creation and Publishing Workflow**
   - Automates content generation with AI agents
   - Publishes to Ghost CMS
   - Workflow ID: [ID from n8n dashboard]

2. **Subscription Management Workflow**
   - Synchronizes subscription data between systems
   - Handles tier changes and payment processing
   - Workflow ID: [ID from n8n dashboard]

3. **Social Media Distribution Workflow**
   - Distributes content to social platforms
   - Customizes content for each platform
   - Workflow ID: [ID from n8n dashboard]

4. **Print Issue Preparation Workflow**
   - Prepares content for print issues
   - Generates PDFs and InDesign packages
   - Workflow ID: [ID from n8n dashboard]

5. **Email Marketing Automation Workflow**
   - Sends personalized emails based on subscriber tier
   - Manages newsletter distribution
   - Workflow ID: [ID from n8n dashboard]

### Access Instructions
1. Log in to the n8n dashboard using your credentials
2. Navigate to Workflows to view and edit existing workflows
3. Use the Execute button to manually trigger workflows
4. Check Executions to monitor workflow runs and troubleshoot issues

## Ghost CMS

### Instance Details
- **Ghost Admin URL:** https://rainbow-millipede.pikapod.net/ghost
- **Public Site URL:** https://rainbow-millipede.pikapod.net

### API Credentials
```javascript
// Ghost Admin API
const ghostAdminKey = '67ef67107bdbb900014522e2:a83281ff2c5c9eb4ee94242f87cd1e8ace9d4cb9317358acda25f8ec1f266d73';

// Ghost Content API
const ghostContentKey = 'bbc75241a46836b87673d05b12';
```

### Access Instructions
1. Log in to the Ghost Admin panel at https://rainbow-millipede.pikapod.net/ghost
2. Use the Content section to manage posts and pages
3. Use the Staff section to manage team members and permissions
4. Use the Settings section to configure site settings and integrations

## NVIDIA Digital Human Implementation

### Instance Details
- **NVIDIA Omniverse URL:** [Your Omniverse instance URL]
- **Digital Human Dashboard:** [Dashboard URL]

### Access Instructions
1. Log in to the NVIDIA Omniverse platform using your credentials
2. Navigate to the Luxe Queer project space
3. Access the Octavia digital human model and configurations
4. Use the provided tools to manage expressions, animations, and voice synchronization

## Hugging Face Integration

### Organization Details
- **Organization URL:** https://huggingface.co/organizations/[your-org-name]
- **Model Repository:** https://huggingface.co/[your-org-name]/octavia-voice

### Access Instructions
1. Log in to Hugging Face using your credentials
2. Navigate to the organization page
3. Access the model repositories for voice and other AI components
4. Use the Spaces section to interact with deployed demos

## SMS Notification System

### Instance Details
- **Admin Phone Number:** (619) 457-4232
- **SMS Provider Dashboard:** [Provider dashboard URL]

### Access Instructions
1. Log in to the SMS provider dashboard using your credentials
2. Navigate to the Campaigns section to manage SMS campaigns
3. Use the Templates section to manage message templates
4. Check the Analytics section to monitor delivery and engagement metrics

## Additional Systems

### Stripe Payment Processing
- **Dashboard URL:** https://dashboard.stripe.com
- **Account ID:** [Your Stripe account ID]

### AWS S3 Storage
- **Console URL:** https://console.aws.amazon.com/s3/
- **Bucket Name:** [Your S3 bucket name]

### GitHub Repository
- **Repository URL:** https://github.com/[username]/luxe-queer-magazine
- **Branch Structure:**
  - `main` - Production code
  - `staging` - Staging environment
  - `development` - Development work

## Emergency Contacts

### Technical Support
- **Primary Contact:** [Name], [Email], [Phone]
- **Secondary Contact:** [Name], [Email], [Phone]

### Service Providers
- **Supabase Support:** support@supabase.io
- **n8n Support:** support@n8n.io
- **Ghost Support:** support@ghost.org

## Security Protocols

### API Key Rotation
- Supabase API keys should be rotated quarterly
- n8n API keys should be rotated quarterly
- Ghost API keys should be rotated semi-annually

### Access Control
- Follow the principle of least privilege for all system access
- Use strong, unique passwords for all services
- Enable two-factor authentication where available

### Data Backup
- Supabase database is backed up daily
- Ghost content is backed up weekly
- All backups are stored in the designated AWS S3 bucket

## Maintenance Schedule

### Regular Maintenance
- Supabase: Weekly performance optimization (Sundays, 2 AM UTC)
- n8n: Bi-weekly workflow review and optimization (Every other Monday)
- Ghost CMS: Monthly plugin updates (First Tuesday of each month)

### Monitoring
- System health is monitored 24/7 via [Monitoring Service]
- Alerts are configured to notify the technical team of any issues

## Troubleshooting Guide

### Common Issues and Solutions

#### Supabase Connection Issues
1. Check API key validity
2. Verify network connectivity
3. Check for service status at https://status.supabase.com

#### n8n Workflow Failures
1. Check execution logs in the n8n dashboard
2. Verify API credentials for integrated services
3. Check for changes in external API endpoints

#### Ghost CMS Publishing Issues
1. Verify Ghost API key validity
2. Check for content formatting issues
3. Verify webhook configurations

## Recovery Procedures

### Database Recovery
1. Log in to Supabase dashboard
2. Navigate to the Backups section
3. Select the appropriate backup point
4. Follow the restoration procedure

### Workflow Recovery
1. Export workflows from n8n as JSON
2. Store backups in the designated GitHub repository
3. Import workflows from backups when needed

This comprehensive guide provides all necessary access information for the systems powering Luxe Queer Magazine. For additional assistance, contact the technical support team.
