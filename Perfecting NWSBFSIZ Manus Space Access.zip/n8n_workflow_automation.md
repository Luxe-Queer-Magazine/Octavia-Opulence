# n8n Workflow Automation for Luxe Queer Magazine

## Introduction

This document provides comprehensive documentation for implementing workflow automation for Luxe Queer magazine using n8n. By integrating n8n with Ghost CMS and Supabase, we can automate various processes related to content publishing, subscription management, social media distribution, and print production.

## Authentication and Setup

### API Credentials

**n8n API Key:**
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2ZjcyOGQ2YS0wMGUzLTQ4YTgtYTk2NS0zODBjZWIxYWNjYmQiLCJpc3MiOiJuOG4iLCJhdWQiOiJwdWJsaWMtYXBpIiwiaWF0IjoxNzQzODU1MDc1LCJleHAiOjE3NDY0MTc2MDB9.lhT_Q6hMnFZKEg0twL1WhLU3RF2YmEucyQhMiDkg7qY
```

**Ghost CMS Credentials:**
- URL: `https://rainbow-millipede.pikapod.net`
- Admin API Key: `67ef67107bdbb900014522e2:a83281ff2c5c9eb4ee94242f87cd1e8ace9d4cb9317358acda25f8ec1f266d73`
- Content API Key: `bbc75241a46836b87673d05b12`
- API Version: `v3`

**Supabase Credentials:**
- Configure in n8n with your Supabase project URL and API key

### Initial Setup

1. **Install n8n:**
   ```bash
   npm install n8n -g
   ```

2. **Start n8n:**
   ```bash
   n8n start
   ```

3. **Access the n8n Dashboard:**
   - Open your browser and navigate to `http://localhost:5678`
   - Log in with your credentials

4. **Configure Credentials:**
   - Go to Settings > Credentials
   - Add Ghost API credentials
   - Add Supabase credentials
   - Add other necessary credentials (Stripe, social media platforms, etc.)

## Core Workflows

### 1. AI Content Creation and Publishing Workflow

This workflow automates the process of generating content with AI agents and publishing it to Ghost CMS.

**Workflow Steps:**

1. **Trigger: Schedule**
   - Configure to run on a regular schedule (e.g., weekly for content planning)

2. **HTTP Request: Fetch Content Brief**
   - Fetch content brief from Supabase or external system

3. **AI Agent Orchestration**
   - HTTP Request to each AI agent API with content brief
   - Configure for each AI provider (Cohere, Anthropic, Nvidia, etc.)
   - Example for Anthropic Claude:
     ```json
     {
       "url": "https://api.anthropic.com/v1/messages",
       "method": "POST",
       "headers": {
         "x-api-key": "{{$node['Credentials'].json.anthropicApiKey}}",
         "content-type": "application/json"
       },
       "body": {
         "model": "claude-3-opus-20240229",
         "max_tokens": 4000,
         "messages": [
           {
             "role": "user",
             "content": "Create an article for Luxe Queer magazine on {{$node['Content Brief'].json.topic}}. Focus on {{$node['Content Brief'].json.angle}} with a luxury perspective. Use the Octavia Opulence³ brand voice that balances sophistication with sass and incorporates references to queer culture."
           }
         ]
       }
     }
     ```

4. **Content Aggregation and Editing**
   - Function node to combine AI outputs
   - Apply editorial guidelines and formatting
   - Example function:
     ```javascript
     // Combine content from multiple AI agents
     const combinedContent = {
       title: $input.item(0).json.title,
       introduction: $input.item(1).json.content.substring(0, 500),
       mainContent: $input.item(2).json.content,
       conclusion: $input.item(3).json.content.substring($input.item(3).json.content.length - 500),
       attribution: `This article was created collaboratively by the Luxe Queer AI agent team, featuring contributions from ${$input.item(0).json.agent}, ${$input.item(1).json.agent}, ${$input.item(2).json.agent}, and ${$input.item(3).json.agent}.`
     };
     
     // Format according to Ghost CMS requirements
     const formattedContent = `
     # ${combinedContent.title}
     
     ${combinedContent.introduction}
     
     ${combinedContent.mainContent}
     
     ${combinedContent.conclusion}
     
     ---
     
     ${combinedContent.attribution}
     `;
     
     return {json: {formattedContent}};
     ```

5. **Ghost CMS: Create Draft Post**
   - Use Ghost node to create a draft post
   - Configure with:
     - Title from AI output
     - Content from aggregated AI content
     - Tags based on content category
     - Featured image (placeholder or AI-generated)

6. **Notification: Editorial Review**
   - Send email notification to editorial team
   - Include link to draft post for review

7. **Wait: Editorial Approval**
   - Webhook trigger for editorial approval
   - Continue workflow when approved

8. **Ghost CMS: Update Post Status**
   - Update post status to "published"
   - Schedule publication date if needed

9. **Supabase: Update Content Tracking**
   - Record publication in Supabase database
   - Track AI agent contributions and performance

**Example n8n Workflow JSON:**
```json
{
  "nodes": [
    {
      "parameters": {
        "rule": {
          "interval": [
            {
              "field": "days",
              "minutesInterval": 1,
              "hoursInterval": 1
            }
          ]
        }
      },
      "name": "Schedule Trigger",
      "type": "n8n-nodes-base.scheduleTrigger",
      "typeVersion": 1,
      "position": [
        250,
        300
      ]
    },
    {
      "parameters": {
        "url": "https://your-supabase-url.supabase.co/rest/v1/content_briefs?select=*&order=created_at.desc&limit=1",
        "authentication": "predefinedCredentialType",
        "nodeCredentialType": "supabaseApi",
        "sendHeaders": true,
        "headerParameters": {
          "parameters": [
            {
              "name": "apikey",
              "value": "={{ $credentials.supabaseApi.apiKey }}"
            },
            {
              "name": "Authorization",
              "value": "Bearer={{ $credentials.supabaseApi.apiKey }}"
            }
          ]
        }
      },
      "name": "Fetch Content Brief",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 1,
      "position": [
        450,
        300
      ]
    },
    // Additional nodes would follow
  ],
  "connections": {
    "Schedule Trigger": {
      "main": [
        [
          {
            "node": "Fetch Content Brief",
            "type": "main",
            "index": 0
          }
        ]
      ]
    }
    // Additional connections would follow
  }
}
```

### 2. Subscription Management Workflow

This workflow automates the synchronization of subscription data between Ghost CMS, Supabase, and payment processors.

**Workflow Steps:**

1. **Trigger: Webhook from Stripe**
   - Configure to receive Stripe webhook events
   - Filter for subscription-related events

2. **Switch: Event Type**
   - Branch based on event type (created, updated, canceled, etc.)

3. **Function: Process Subscription Data**
   - Extract relevant data from webhook payload
   - Format for database storage
   - Example function:
     ```javascript
     // Extract subscription data from Stripe webhook
     const event = $input.item(0).json;
     const subscription = event.data.object;
     
     // Format for database
     const subscriptionData = {
       stripe_subscription_id: subscription.id,
       customer_id: subscription.customer,
       status: subscription.status,
       tier: subscription.metadata.tier_slug,
       current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
       current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
       cancel_at_period_end: subscription.cancel_at_period_end,
       amount: subscription.items.data[0].price.unit_amount / 100,
       currency: subscription.currency,
       event_type: event.type
     };
     
     return {json: subscriptionData};
     ```

4. **Supabase: Update Subscription**
   - Update subscription data in Supabase
   - Use upsert operation to handle new and existing subscriptions

5. **Ghost CMS: Update Member**
   - Update member status and labels in Ghost CMS
   - Sync subscription tier information

6. **Conditional: Tier Change**
   - Check if subscription tier has changed
   - If yes, trigger tier change workflow

7. **Supabase: Log Transaction**
   - Record transaction details in Supabase
   - Include payment information and subscription changes

8. **Email: Send Confirmation**
   - Send appropriate email based on event type
   - Include subscription details and next steps

**Example n8n Workflow JSON (Partial):**
```json
{
  "nodes": [
    {
      "parameters": {
        "httpMethod": "POST",
        "path": "stripe-webhook",
        "options": {}
      },
      "name": "Stripe Webhook",
      "type": "n8n-nodes-base.webhook",
      "typeVersion": 1,
      "position": [
        250,
        300
      ]
    },
    {
      "parameters": {
        "conditions": {
          "string": [
            {
              "value1": "={{ $json.type }}",
              "operation": "contains",
              "value2": "customer.subscription"
            }
          ]
        }
      },
      "name": "Is Subscription Event?",
      "type": "n8n-nodes-base.if",
      "typeVersion": 1,
      "position": [
        450,
        300
      ]
    }
    // Additional nodes would follow
  ],
  "connections": {
    "Stripe Webhook": {
      "main": [
        [
          {
            "node": "Is Subscription Event?",
            "type": "main",
            "index": 0
          }
        ]
      ]
    }
    // Additional connections would follow
  }
}
```

### 3. Social Media Distribution Workflow

This workflow automates the distribution of content to various social media platforms when new content is published.

**Workflow Steps:**

1. **Trigger: Ghost CMS Webhook**
   - Configure to trigger when a post is published
   - Filter for published status

2. **Ghost CMS: Get Post Details**
   - Fetch complete post details including content and images
   - Extract metadata and tags

3. **Function: Generate Platform-Specific Content**
   - Create tailored content for each social platform
   - Apply character limits and formatting
   - Example function:
     ```javascript
     // Get post data
     const post = $input.item(0).json;
     
     // Generate platform-specific content
     const platformContent = {
       twitter: {
         text: `${post.title} | The category is: EXCELLENCE. Read more on Luxe Queer Magazine. #LuxeQueer #${post.primary_tag.slug.replace(/-/g, '')}`,
         url: post.url,
         image: post.feature_image
       },
       instagram: {
         caption: `${post.title}\n\n${post.excerpt.substring(0, 200)}...\n\nThe category is: EXCELLENCE. 💜\n\nRead the full article on Luxe Queer Magazine (link in bio).\n\n#LuxeQueer #${post.primary_tag.slug.replace(/-/g, '')} #LuxuryLifestyle #QueerExcellence`,
         image: post.feature_image
       },
       linkedin: {
         title: post.title,
         text: `${post.excerpt}\n\nRead the full article on Luxe Queer Magazine.`,
         url: post.url,
         image: post.feature_image
       }
       // Add other platforms as needed
     };
     
     return {json: platformContent};
     ```

4. **Switch: Platform Distribution**
   - Branch for each social media platform

5. **HTTP Request: Twitter/X Post**
   - Post to Twitter/X API
   - Include image if available

6. **HTTP Request: Instagram Post**
   - Post to Instagram API
   - Format as carousel if multiple images

7. **HTTP Request: LinkedIn Post**
   - Post to LinkedIn API
   - Include professional context

8. **HTTP Request: Other Platforms**
   - Additional branches for other platforms
   - Customize content for each

9. **Supabase: Log Distribution**
   - Record distribution details in Supabase
   - Track engagement metrics if available

10. **Notification: Distribution Report**
    - Send summary of distribution to team
    - Include links to posts

### 4. Print Issue Preparation Workflow

This workflow automates the preparation of content for print issues of the magazine.

**Workflow Steps:**

1. **Trigger: Manual or Scheduled**
   - Configure to run on issue preparation schedule
   - Allow manual triggering for special issues

2. **Ghost CMS: Get Issue Content**
   - Fetch all posts with specific issue tag
   - Sort by section and priority

3. **Function: Organize Content Structure**
   - Arrange content according to magazine structure
   - Generate table of contents
   - Example function:
     ```javascript
     // Get all posts for the issue
     const posts = $input.item(0).json;
     
     // Organize by section
     const sections = {
       fashion: posts.filter(post => post.tags.some(tag => tag.slug === 'fashion')),
       art: posts.filter(post => post.tags.some(tag => tag.slug === 'art')),
       culture: posts.filter(post => post.tags.some(tag => tag.slug === 'culture')),
       travel: posts.filter(post => post.tags.some(tag => tag.slug === 'travel')),
       technology: posts.filter(post => post.tags.some(tag => tag.slug === 'technology')),
       luxury: posts.filter(post => post.tags.some(tag => tag.slug === 'luxury'))
     };
     
     // Generate table of contents
     const toc = Object.entries(sections).map(([section, posts]) => {
       return {
         section: section.toUpperCase(),
         articles: posts.map(post => ({
           title: post.title,
           author: post.primary_author.name,
           page: 0 // To be filled later
         }))
       };
     });
     
     return {json: {sections, toc}};
     ```

4. **HTTP Request: Generate PDFs**
   - Call PDF generation service for each article
   - Apply print templates and styling

5. **Function: Combine PDFs**
   - Merge individual PDFs into complete issue
   - Add pagination and references

6. **HTTP Request: Send to InDesign**
   - Prepare package for InDesign
   - Include assets and layout information

7. **Supabase: Update Issue Status**
   - Record issue preparation status
   - Track included content and metadata

8. **Notification: Print Ready**
   - Notify production team of print-ready issue
   - Include links to final files

### 5. Email Marketing Automation Workflow

This workflow automates email communications with subscribers based on their tier and engagement.

**Workflow Steps:**

1. **Trigger: Schedule or Event**
   - Configure to run on schedule for newsletters
   - Trigger on specific events (new issue, subscription change)

2. **Supabase: Get Subscriber Segments**
   - Fetch subscriber lists by tier and preferences
   - Filter for active subscriptions

3. **Ghost CMS: Get Content**
   - Fetch relevant content for email
   - Filter based on subscriber tier

4. **Function: Personalize Content**
   - Customize content for each subscriber segment
   - Apply tier-specific offerings
   - Example function:
     ```javascript
     // Get subscriber segment and content
     const segment = $input.item(0).json;
     const content = $input.item(1).json;
     
     // Personalize based on tier
     const tierContent = {
       'digital-devotee': {
         heading: 'Digital Exclusives for You',
         features: content.filter(item => item.tier <= 1).slice(0, 3),
         cta: 'Read More Online'
       },
       'print-provocateur': {
         heading: 'Your Print Edition is On the Way',
         features: content.filter(item => item.tier <= 2).slice(0, 5),
         cta: 'Preview Online Now'
       },
       'opulence-oracle': {
         heading: 'Exclusive Oracle Insights',
         features: content.filter(item => item.tier <= 3),
         cta: 'Access Your Premium Content',
         special: 'Your quarterly gift selection is now available'
       },
       'category-excellence': {
         heading: 'Excellence Awaits',
         features: content,
         cta: 'Access Your Exclusive Content',
         special: 'Your invitation to our next retreat is enclosed'
       }
     };
     
     const emailContent = tierContent[segment.tier] || tierContent['digital-devotee'];
     
     return {json: {segment, emailContent}};
     ```

5. **HTTP Request: Email Service**
   - Send emails via email service API
   
(Content truncated due to size limit. Use line ranges to read in chunks)