const fs = require('fs');
const path = require('path');
const cheerio = require('cheerio');

// Function to completely remove all highlighting from the website
async function removeAllHighlighting() {
  console.log('Implementing complete highlighting removal from all website elements...');
  
  // Get all HTML files in the website
  const htmlFiles = getAllHtmlFiles('/home/ubuntu/luxe_queer_website');
  console.log(`Found ${htmlFiles.length} HTML files to process`);
  
  // Process each HTML file
  for (const htmlFile of htmlFiles) {
    console.log(`Processing ${htmlFile}...`);
    
    // Read the HTML file
    let html = fs.readFileSync(htmlFile, 'utf8');
    const $ = cheerio.load(html);
    
    // 1. Remove all inline styles that might cause highlighting
    $('*[style]').each(function() {
      const $el = $(this);
      const style = $el.attr('style');
      
      // Remove color styles
      if (style && (
          style.includes('color:') || 
          style.includes('background-color:') || 
          style.includes('text-shadow:') ||
          style.includes('box-shadow:') ||
          style.includes('border-color:') ||
          style.includes('outline-color:')
      )) {
        // Remove the specific style properties rather than the entire style attribute
        let newStyle = style
          .replace(/color\s*:\s*[^;]+;?/g, '')
          .replace(/background-color\s*:\s*[^;]+;?/g, '')
          .replace(/text-shadow\s*:\s*[^;]+;?/g, '')
          .replace(/box-shadow\s*:\s*[^;]+;?/g, '')
          .replace(/border-color\s*:\s*[^;]+;?/g, '')
          .replace(/outline-color\s*:\s*[^;]+;?/g, '');
        
        // If there's still some style left, set it, otherwise remove the style attribute
        if (newStyle.trim()) {
          $el.attr('style', newStyle.trim());
        } else {
          $el.removeAttr('style');
        }
      }
    });
    
    // 2. Remove all classes that might cause highlighting
    $('*[class]').each(function() {
      const $el = $(this);
      const classes = $el.attr('class').split(/\s+/);
      
      // Filter out classes that might cause highlighting
      const newClasses = classes.filter(cls => 
        !cls.includes('highlight') && 
        !cls.includes('color') && 
        !cls.includes('accent') &&
        !cls.includes('blue') &&
        !cls.includes('glow')
      );
      
      if (newClasses.length > 0) {
        $el.attr('class', newClasses.join(' '));
      } else {
        $el.removeAttr('class');
      }
    });
    
    // 3. Specifically target and remove any span elements used for highlighting
    $('span').each(function() {
      const $span = $(this);
      const style = $span.attr('style');
      const classes = $span.attr('class');
      
      // If the span has a style with color or a highlighting class, replace it with its contents
      if ((style && (
          style.includes('color:') || 
          style.includes('background-color:') || 
          style.includes('text-shadow:')
      )) || 
      (classes && (
          classes.includes('highlight') || 
          classes.includes('color') || 
          classes.includes('accent') ||
          classes.includes('blue') ||
          classes.includes('glow')
      ))) {
        $span.replaceWith($span.html());
      }
    });
    
    // 4. Remove any SVG filters that might be used for highlighting
    $('filter, feColorMatrix, feBlend, feGaussianBlur').remove();
    
    // 5. Ensure all text in headings is plain without highlighting
    $('h1, h2, h3, h4, h5, h6').each(function() {
      const $heading = $(this);
      
      // Remove any inline styles
      $heading.removeAttr('style');
      
      // Remove any classes that might cause highlighting
      const classes = $heading.attr('class');
      if (classes) {
        const newClasses = classes.split(/\s+/).filter(cls => 
          !cls.includes('highlight') && 
          !cls.includes('color') && 
          !cls.includes('accent') &&
          !cls.includes('blue') &&
          !cls.includes('glow')
        );
        
        if (newClasses.length > 0) {
          $heading.attr('class', newClasses.join(' '));
        } else {
          $heading.removeAttr('class');
        }
      }
      
      // Replace any spans inside with their contents
      $heading.find('span').each(function() {
        const $span = $(this);
        $span.replaceWith($span.html());
      });
    });
    
    // 6. Ensure hero section has no highlighting
    $('.hero, .hero-section, #hero').each(function() {
      const $hero = $(this);
      
      // Update hero content to ensure no highlighting
      $hero.find('.hero-content h1, .hero-content h2, .hero-content p').css({
        'text-shadow': 'none',
        'color': 'white'
      });
      
      // Remove any highlighting spans
      $hero.find('span[style*="color"]').each(function() {
        const $span = $(this);
        $span.replaceWith($span.html());
      });
    });
    
    // 7. Ensure all links have consistent styling without highlighting
    $('a').each(function() {
      const $link = $(this);
      
      // Remove any inline styles that might cause highlighting
      const style = $link.attr('style');
      if (style && (
          style.includes('color:') || 
          style.includes('background-color:') || 
          style.includes('text-shadow:')
      )) {
        let newStyle = style
          .replace(/color\s*:\s*[^;]+;?/g, '')
          .replace(/background-color\s*:\s*[^;]+;?/g, '')
          .replace(/text-shadow\s*:\s*[^;]+;?/g, '');
        
        if (newStyle.trim()) {
          $link.attr('style', newStyle.trim());
        } else {
          $link.removeAttr('style');
        }
      }
    });
    
    // Write the updated HTML back to the file
    fs.writeFileSync(htmlFile, $.html());
    console.log(`Updated ${htmlFile} with highlighting removed`);
  }
  
  // Process all CSS files to remove highlighting styles
  const cssFiles = getAllCssFiles('/home/ubuntu/luxe_queer_website');
  console.log(`Found ${cssFiles.length} CSS files to process`);
  
  for (const cssFile of cssFiles) {
    console.log(`Processing ${cssFile}...`);
    
    // Read the CSS file
    let css = fs.readFileSync(cssFile, 'utf8');
    
    // Remove color-related styles
    css = css
      // Remove color properties
      .replace(/color\s*:\s*[^;]+;/g, 'color: inherit;')
      .replace(/background-color\s*:\s*[^;]+;/g, 'background-color: transparent;')
      .replace(/text-shadow\s*:\s*[^;]+;/g, 'text-shadow: none;')
      .replace(/box-shadow\s*:\s*[^;]+;/g, 'box-shadow: none;')
      .replace(/border-color\s*:\s*[^;]+;/g, 'border-color: inherit;')
      .replace(/outline-color\s*:\s*[^;]+;/g, 'outline-color: inherit;')
      
      // Remove animation and transition properties that might cause highlighting
      .replace(/animation\s*:\s*[^;]+;/g, 'animation: none;')
      .replace(/transition\s*:\s*[^;]+;/g, 'transition: none;')
      
      // Remove filter properties that might cause highlighting
      .replace(/filter\s*:\s*[^;]+;/g, 'filter: none;')
      .replace(/-webkit-filter\s*:\s*[^;]+;/g, '-webkit-filter: none;');
    
    // Write the updated CSS back to the file
    fs.writeFileSync(cssFile, css);
    console.log(`Updated ${cssFile} with highlighting styles removed`);
  }
  
  // Create a new CSS file to ensure consistent styling without highlighting
  const newCssContent = `
/* Reset all highlighting styles */
* {
  text-shadow: none !important;
  box-shadow: none !important;
  filter: none !important;
  -webkit-filter: none !important;
  animation: none !important;
  transition: none !important;
}

/* Ensure hero content has no highlighting */
.hero-content h1, 
.hero-content h2, 
.hero-content p {
  color: white !important;
  text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5) !important;
}

/* Ensure all headings have no highlighting */
h1, h2, h3, h4, h5, h6 {
  color: inherit !important;
}

/* Ensure all links have consistent styling */
a {
  color: inherit !important;
  text-decoration: none !important;
}

/* Ensure all spans have no highlighting */
span {
  color: inherit !important;
}
`;
  
  fs.writeFileSync(path.join('/home/ubuntu/luxe_queer_website', 'css', 'no-highlighting.css'), newCssContent);
  console.log('Created new CSS file to ensure no highlighting');
  
  // Update all HTML files to include the new CSS file
  for (const htmlFile of htmlFiles) {
    console.log(`Adding no-highlighting CSS to ${htmlFile}...`);
    
    // Read the HTML file
    let html = fs.readFileSync(htmlFile, 'utf8');
    const $ = cheerio.load(html);
    
    // Add the new CSS file
    $('head').append('<link rel="stylesheet" href="/css/no-highlighting.css">');
    
    // Write the updated HTML back to the file
    fs.writeFileSync(htmlFile, $.html());
    console.log(`Added no-highlighting CSS to ${htmlFile}`);
  }
  
  console.log('All highlighting has been completely removed from the website!');
}

// Helper function to get all HTML files in a directory and its subdirectories
function getAllHtmlFiles(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  
  for (const file of list) {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    
    if (stat.isDirectory()) {
      // Recursively get HTML files from subdirectories
      results = results.concat(getAllHtmlFiles(filePath));
    } else if (path.extname(filePath).toLowerCase() === '.html') {
      // Add HTML files to the results
      results.push(filePath);
    }
  }
  
  return results;
}

// Helper function to get all CSS files in a directory and its subdirectories
function getAllCssFiles(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  
  for (const file of list) {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    
    if (stat.isDirectory()) {
      // Recursively get CSS files from subdirectories
      results = results.concat(getAllCssFiles(filePath));
    } else if (path.extname(filePath).toLowerCase() === '.css') {
      // Add CSS files to the results
      results.push(filePath);
    }
  }
  
  return results;
}

// Run the function to remove all highlighting
removeAllHighlighting().catch(console.error);
