// Script to fix duplicate menu issues across all HTML files
const fs = require('fs');
const path = require('path');

// Function to fix the header in HTML files
function fixHeader(content) {
  // Regular expression to match the header section with duplicate menus
  const headerRegex = /<header>[\s\S]*?<\/header>/;
  
  // Check if the content contains a header
  if (!headerRegex.test(content)) {
    return content;
  }
  
  // Extract the header
  const headerMatch = content.match(headerRegex);
  if (!headerMatch) {
    return content;
  }
  
  const header = headerMatch[0];
  
  // Check if the header contains duplicate menu elements
  if (header.includes('mobile-menu-toggle') || 
      (header.includes('<!-- Hamburger Menu Button -->') && 
       header.split('<!-- Hamburger Menu Button -->').length > 2)) {
    
    // Create a clean header structure
    let cleanHeader;
    
    // For index.html (root page)
    if (content.includes('href="index.html"')) {
      cleanHeader = `<header>
        <div class="container header-container">
            <a href="index.html" class="logo"><img src="/images/logo-blue-lips.png" alt="Luxe Queer Magazine"></a>
            <nav role="navigation" aria-label="Main Navigation">
                <ul>
                    <li><a href="pages/about.html">ABOUT</a></li>
                    <li><a href="pages/features.html">FEATURES</a></li>
                    <li><a href="pages/octavia.html">OCTAVIA</a></li>
                    <li><a href="pages/subscribe.html">SUBSCRIBE</a></li>
                </ul>
            </nav>
            <!-- Hamburger Menu Button -->
            <button class="hamburger-menu" aria-label="Toggle navigation menu" aria-expanded="false">
              <div class="hamburger-line"></div>
              <div class="hamburger-line"></div>
              <div class="hamburger-line"></div>
            </button>
        </div>
        
        <!-- Mobile Navigation -->
        <div class="mobile-nav">
          <ul>
            <li><a href="pages/about.html">ABOUT</a></li>
            <li><a href="pages/features.html">FEATURES</a></li>
            <li><a href="pages/octavia.html">OCTAVIA</a></li>
            <li><a href="pages/subscribe.html">SUBSCRIBE</a></li>
            <li><a href="pages/user-guide.html">USER GUIDE</a></li>
            <li><a href="pages/privacy-policy.html">PRIVACY</a></li>
            <li><a href="pages/terms-of-service.html">TERMS</a></li>
          </ul>
        </div>
    </header>`;
    } 
    // For pages in the pages directory
    else {
      cleanHeader = `<header>
        <div class="container header-container">
            <a href="../index.html" class="logo"><img src="/images/logo-blue-lips.png" alt="Luxe Queer Magazine"></a>
            <nav role="navigation" aria-label="Main Navigation">
                <ul>
                    <li><a href="about.html">ABOUT</a></li>
                    <li><a href="features.html">FEATURES</a></li>
                    <li><a href="octavia.html">OCTAVIA</a></li>
                    <li><a href="subscribe.html">SUBSCRIBE</a></li>
                </ul>
            </nav>
            <!-- Hamburger Menu Button -->
            <button class="hamburger-menu" aria-label="Toggle navigation menu" aria-expanded="false">
              <div class="hamburger-line"></div>
              <div class="hamburger-line"></div>
              <div class="hamburger-line"></div>
            </button>
        </div>
        
        <!-- Mobile Navigation -->
        <div class="mobile-nav">
          <ul>
            <li><a href="about.html">ABOUT</a></li>
            <li><a href="features.html">FEATURES</a></li>
            <li><a href="octavia.html">OCTAVIA</a></li>
            <li><a href="subscribe.html">SUBSCRIBE</a></li>
            <li><a href="user-guide.html">USER GUIDE</a></li>
            <li><a href="privacy-policy.html">PRIVACY</a></li>
            <li><a href="terms-of-service.html">TERMS</a></li>
          </ul>
        </div>
    </header>`;
    }
    
    // Replace the old header with the clean one
    return content.replace(headerRegex, cleanHeader);
  }
  
  return content;
}

// Process index.html
const indexPath = path.join(__dirname, 'index.html');
if (fs.existsSync(indexPath)) {
  const indexContent = fs.readFileSync(indexPath, 'utf8');
  const fixedIndexContent = fixHeader(indexContent);
  fs.writeFileSync(indexPath, fixedIndexContent);
  console.log('Fixed index.html');
}

// Process all HTML files in the pages directory
const pagesDir = path.join(__dirname, 'pages');
if (fs.existsSync(pagesDir)) {
  const files = fs.readdirSync(pagesDir);
  
  files.forEach(file => {
    if (path.extname(file) === '.html') {
      const filePath = path.join(pagesDir, file);
      const content = fs.readFileSync(filePath, 'utf8');
      const fixedContent = fixHeader(content);
      
      fs.writeFileSync(filePath, fixedContent);
      console.log(`Fixed ${file}`);
    }
  });
}

console.log('All duplicate menu issues have been fixed!');
