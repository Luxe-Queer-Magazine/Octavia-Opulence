# Luxe Queer Magazine - Detailed Deployment Guide

This comprehensive guide provides step-by-step instructions for deploying the Luxe Queer Magazine website and SMS notification system to production.

## Table of Contents

1. [Website Deployment](#website-deployment)
   - [Preparation](#preparation)
   - [Deployment Options](#deployment-options)
   - [Domain Configuration](#domain-configuration)
   - [Post-Deployment Verification](#post-deployment-verification)

2. [SMS Integration Deployment](#sms-integration-deployment)
   - [Twilio Setup](#twilio-setup)
   - [Backend Integration](#backend-integration)
   - [Testing Procedure](#testing-procedure)
   - [Production Launch](#production-launch)

## Website Deployment

### Preparation

Before deploying the website, ensure all files are properly prepared:

1. **File Organization Check**
   ```bash
   # Navigate to the website directory
   cd /home/ubuntu/luxe_queer_website
   
   # List all directories and files to verify structure
   ls -la
   
   # Verify all HTML pages exist
   ls -la pages/
   
   # Verify all CSS files exist
   ls -la css/
   
   # Verify all JavaScript files exist
   ls -la js/
   
   # Verify all images exist
   ls -la images/
   ```

2. **Domain Reference Verification**
   ```bash
   # Check for any remaining references to the old domain
   grep -r "nwsbfsiz.manus.space" --include="*.html" --include="*.js" --include="*.css" .
   
   # Verify all references are to the new domain
   grep -r "luxequeer.com" --include="*.html" --include="*.js" --include="*.css" .
   ```

3. **File Permissions**
   ```bash
   # Set appropriate permissions for all files
   find . -type f -exec chmod 644 {} \;
   
   # Set appropriate permissions for all directories
   find . -type d -exec chmod 755 {} \;
   ```

### Deployment Options

#### Option 1: Traditional Web Hosting (Recommended for Static Site)

1. **FTP/SFTP Upload**
   ```bash
   # Using SFTP (replace with your hosting details)
   sftp username@your-hosting-server.com
   cd public_html
   put -r /home/ubuntu/luxe_queer_website/* .
   exit
   ```

2. **Using rsync**
   ```bash
   # Using rsync (replace with your hosting details)
   rsync -avz --delete /home/ubuntu/luxe_queer_website/ username@your-hosting-server.com:public_html/
   ```

#### Option 2: GitHub Pages Deployment

1. **Create a GitHub Repository**
   ```bash
   # Initialize git repository
   cd /home/ubuntu/luxe_queer_website
   git init
   git add .
   git commit -m "Initial commit of Luxe Queer Magazine website"
   
   # Add GitHub remote (replace with your GitHub details)
   git remote add origin https://github.com/yourusername/luxe-queer-magazine.git
   git push -u origin main
   ```

2. **Configure GitHub Pages**
   - Go to your GitHub repository
   - Navigate to Settings > Pages
   - Select "main" branch as the source
   - Click Save
   - Configure custom domain to point to luxequeer.com

#### Option 3: AWS S3 Static Website Hosting

1. **Create an S3 Bucket**
   ```bash
   # Install AWS CLI if not already installed
   pip install awscli
   
   # Configure AWS credentials
   aws configure
   
   # Create S3 bucket
   aws s3 mb s3://luxequeer.com
   
   # Enable static website hosting
   aws s3 website s3://luxequeer.com --index-document index.html --error-document error.html
   
   # Upload website files
   aws s3 sync /home/ubuntu/luxe_queer_website/ s3://luxequeer.com/
   ```

2. **Configure CloudFront (Optional but Recommended)**
   - Create a CloudFront distribution pointing to your S3 bucket
   - Configure SSL certificate for HTTPS
   - Set up cache behaviors for optimal performance

### Domain Configuration

1. **DNS Configuration**
   - Log in to your domain registrar (e.g., GoDaddy, Namecheap, etc.)
   - Update DNS settings to point to your hosting provider:
     - For traditional hosting: Set A records to your hosting IP
     - For GitHub Pages: Set CNAME record to your GitHub Pages URL
     - For AWS: Set ALIAS/ANAME record to your CloudFront distribution

2. **SSL Certificate**
   - Obtain an SSL certificate for luxequeer.com
   - For traditional hosting: Install certificate via hosting control panel
   - For GitHub Pages: Enable HTTPS in repository settings
   - For AWS: Use AWS Certificate Manager with CloudFront

3. **Verify DNS Propagation**
   ```bash
   # Check DNS propagation
   dig luxequeer.com
   
   # Check HTTPS configuration
   curl -I https://luxequeer.com
   ```

### Post-Deployment Verification

1. **Browser Testing**
   - Visit https://luxequeer.com in multiple browsers (Chrome, Firefox, Safari, Edge)
   - Test on multiple devices (desktop, tablet, mobile)
   - Verify all pages load correctly
   - Test hamburger menu functionality
   - Verify all links work properly

2. **Performance Testing**
   - Use Google PageSpeed Insights to test performance
   - Use GTmetrix to identify any performance issues
   - Optimize images or code if necessary

3. **Accessibility Testing**
   - Use WAVE Web Accessibility Evaluation Tool
   - Verify compliance with WCAG guidelines
   - Make necessary adjustments for accessibility

## SMS Integration Deployment

### Twilio Setup

1. **Create Twilio Account**
   - Sign up at https://www.twilio.com
   - Verify your email and phone number
   - Complete account setup

2. **Purchase Phone Number**
   - Navigate to Phone Numbers > Buy a Number
   - Search for a number with SMS capabilities
   - Purchase the number

3. **Set Up Messaging Service**
   ```bash
   # Note your Account SID and Auth Token from Twilio dashboard
   export TWILIO_ACCOUNT_SID="your_account_sid"
   export TWILIO_AUTH_TOKEN="your_auth_token"
   export TWILIO_PHONE_NUMBER="your_twilio_phone_number"
   ```

4. **Configure Webhooks**
   - In Twilio dashboard, navigate to Phone Numbers > Manage > Active Numbers
   - Select your number
   - Under Messaging, set webhook URL for incoming messages to:
     `https://luxequeer.com/api/sms-webhook`

### Backend Integration

1. **Create Backend API**
   Create a new file `/home/ubuntu/luxe_queer_website/server/sms-integration.js`:

   ```javascript
   // Install required packages
   // npm install express twilio body-parser dotenv
   
   require('dotenv').config();
   const express = require('express');
   const bodyParser = require('body-parser');
   const twilio = require('twilio');
   
   const app = express();
   app.use(bodyParser.urlencoded({ extended: false }));
   app.use(bodyParser.json());
   
   // Initialize Twilio client
   const client = new twilio(
     process.env.TWILIO_ACCOUNT_SID,
     process.env.TWILIO_AUTH_TOKEN
   );
   
   // Function to send SMS
   async function sendSMS(phoneNumber, message) {
     try {
       const result = await client.messages.create({
         body: message,
         from: process.env.TWILIO_PHONE_NUMBER,
         to: phoneNumber
       });
       
       console.log(`Message sent with SID: ${result.sid}`);
       return result;
     } catch (error) {
       console.error(`Error sending message: ${error.message}`);
       throw error;
     }
   }
   
   // Handle opt-in form submission
   app.post('/api/sms-opt-in', async (req, res) => {
     const { phone, preferences, consent } = req.body;
     
     // Validate input
     if (!phone || !consent) {
       return res.status(400).json({ error: 'Missing required fields' });
     }
     
     try {
       // In a production environment, save to database here
       console.log(`New opt-in: ${phone}, Preferences: ${JSON.stringify(preferences)}`);
       
       // Send confirmation message
       await sendSMS(
         phone,
         'LUXE QUEER: Thank you for subscribing to SMS notifications! Reply HELP for help or STOP to unsubscribe at any time.'
       );
       
       // Also send notification to admin
       await sendSMS(
         '6194574232', // Admin number
         `LUXE QUEER ADMIN: New SMS subscriber: ${phone}`
       );
       
       return res.status(200).json({ success: true });
     } catch (error) {
       return res.status(500).json({ error: error.message });
     }
   });
   
   // Handle incoming messages (webhook)
   app.post('/api/sms-webhook', (req, res) => {
     const { Body, From } = req.body;
     
     console.log(`Received message from ${From}: ${Body}`);
     
     // Handle STOP command
     if (Body.trim().toUpperCase() === 'STOP') {
       // In a production environment, update opt-out status in database here
       console.log(`Opt-out request from ${From}`);
       
       // Send confirmation
       client.messages.create({
         body: 'LUXE QUEER: You have been unsubscribed from SMS notifications. You will not receive any more messages.',
         from: process.env.TWILIO_PHONE_NUMBER,
         to: From
       });
       
       // Also notify admin
       client.messages.create({
         body: `LUXE QUEER ADMIN: User ${From} has opted out of SMS notifications.`,
         from: process.env.TWILIO_PHONE_NUMBER,
         to: '6194574232' // Admin number
       });
     }
     
     // Handle HELP command
     if (Body.trim().toUpperCase() === 'HELP') {
       client.messages.create({
         body: 'LUXE QUEER: For help with your subscription, visit luxequeer.com/help or contact support at info@luxequeer.com. Reply STOP to unsubscribe.',
         from: process.env.TWILIO_PHONE_NUMBER,
         to: From
       });
     }
     
     res.status(200).send();
   });
   
   // Start server
   const PORT = process.env.PORT || 3000;
   app.listen(PORT, () => {
     console.log(`Server running on port ${PORT}`);
   });
   ```

2. **Create Environment File**
   Create a new file `/home/ubuntu/luxe_queer_website/server/.env`:

   ```
   TWILIO_ACCOUNT_SID=your_account_sid
   TWILIO_AUTH_TOKEN=your_auth_token
   TWILIO_PHONE_NUMBER=your_twilio_phone_number
   PORT=3000
   ```

3. **Update Frontend Form**
   Modify the form submission in `/home/ubuntu/luxe_queer_website/pages/sms-opt-in.html`:

   ```javascript
   // Replace the existing form submission code with:
   document.getElementById('sms-opt-in-form').addEventListener('submit', function(e) {
     e.preventDefault();
     
     // Get form values
     const phone = document.getElementById('phone').value;
     const contentUpdates = document.getElementById('content-updates').checked;
     const accountNotifications = document.getElementById('account-notifications').checked;
     const specialAnnouncements = document.getElementById('special-announcements').checked;
     const consent = document.getElementById('consent').checked;
     
     // Validate phone number (basic validation)
     const phoneRegex = /^\(\d{3}\) \d{3}-\d{4}$|^\d{10}$/;
     if (!phoneRegex.test(phone)) {
       alert('Please enter a valid phone number in the format (123) 456-7890 or 1234567890');
       return;
     }
     
     // Prepare preferences object
     const preferences = {
       contentUpdates,
       accountNotifications,
       specialAnnouncements
     };
     
     // Send to backend API
     fetch('/api/sms-opt-in', {
       method: 'POST',
       headers: {
         'Content-Type': 'application/json'
       },
       body: JSON.stringify({
         phone: phone.replace(/\D/g, ''), // Strip non-digits
         preferences,
         consent
       })
     })
     .then(response => response.json())
     .then(data => {
       if (data.success) {
         alert('Thank you for subscribing to SMS notifications from Luxe Queer Magazine! You will receive a confirmation message shortly.');
         this.reset();
       } else {
         alert('Error: ' + (data.error || 'Unknown error occurred'));
       }
     })
     .catch(error => {
       console.error('Error:', error);
       alert('An error occurred. Please try again later.');
     });
   });
   ```

4. **Deploy Backend**
   ```bash
   # Create server directory on hosting
   ssh username@your-hosting-server.com "mkdir -p ~/server"
   
   # Upload server files
   scp /home/ubuntu/luxe_queer_website/server/* username@your-hosting-server.com:~/server/
   
   # Install dependencies
   ssh username@your-hosting-server.com "cd ~/server && npm install express twilio body-parser dotenv"
   
   # Start server (or use PM2 for production)
   ssh username@your-hosting-server.com "cd ~/server && node sms-integration.js"
   ```

5. **Using PM2 for Production (Recommended)**
   ```bash
   # Install PM2
   ssh username@your-hosting-server.com "npm install -g pm2"
   
   # Start server with PM2
   ssh username@your-hosting-server.com "cd ~/server && pm2 start sms-integration.js --name luxe-queer-sms"
   
   # Set PM2 to start on server boot
   ssh username@your-hosting-server.com "pm2 startup && pm2 save"
   ```

### Testing Procedure

1. **Initial Testing with Admin Number**
   ```bash
   # Send test message to admin number
   curl -X POST https://api.twilio.com/2010-04-01/Accounts/$TWILIO_ACCOUNT_SID/Messages.json \
     --data-urlencode "To=+16194574232" \
     --data-urlencode "From=+$TWILIO_PHONE_NUMBER" \
     --data-urlencode "Body=LUXE QUEER: This is a test message for the SMS notification system." \
     -u $TWILIO_ACCOUNT_SID:$TWILIO_AUTH_TOKEN
   ```

2. **Test Opt-in Flow**
   - Visit https://luxequeer.com/pages/sms-opt-in.html
   - Fill out the form with the admin number (619) 457-4232
   - Check for confirmation message
   - Verify receipt of SMS

3. **Test Opt-out Flow**
   - Reply "STOP" to a received message
   - Verify receipt of opt-out confirmation
   - Verify admin notification of opt-out

4. **Test Help Flow**
   - Reply "HELP" to a received message
   - Verify receipt of help message

### Production Launch

1. **Final Verification**
   - Verify all components are working correctly
   - Check server logs for any errors
   - Test with multiple phone numbers

2. **Database Integration**
   - Set up proper database for subscriber information
   - Update code to save subscriber data to database
   - Implement proper data security measures

3. **Monitoring Setup**
   - Set up monitoring for the SMS service
   - Configure alerts for service disruptions
   - Implement logging for all SMS activities

4. **Launch Announcement**
   - Update website to promote SMS notification service
   - Send email to existing subscribers about the new service
   - Add SMS opt-in option to subscription process

## Conclusion

Following this deployment guide will ensure that both the Luxe Queer Magazine website and SMS notification system are properly deployed and functioning. The guide provides detailed steps for different deployment options, allowing you to choose the most appropriate method for your specific needs.

For any questions or assistance with deployment, please contact the development team.

---

*Document prepared by Manus AI - April 10, 2025*
