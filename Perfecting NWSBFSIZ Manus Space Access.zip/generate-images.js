// Image generation script for Luxe Queer Magazine website
const fs = require('fs');
const path = require('path');
const { createCanvas } = require('canvas');

// Configuration
const outputDir = path.join(__dirname, 'images');
const colors = {
  deepWineRed: '#800020',
  midnightBlue: '#191970',
  verdigris: '#43B3AE',
  burnishedGold: '#DAA520',
  softLavender: '#E6E6FA',
  matteBlack: '#28282B',
  blueLipstick: '#1e90ff'
};

// Ensure output directory exists
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}

// Helper function to create a placeholder image
function createPlaceholderImage(filename, width, height, bgColor, text, textColor = '#FFFFFF') {
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  
  // Background
  ctx.fillStyle = bgColor;
  ctx.fillRect(0, 0, width, height);
  
  // Blue lipstick accent
  ctx.fillStyle = colors.blueLipstick;
  ctx.fillRect(0, 0, width, 5);
  
  // Text
  ctx.fillStyle = textColor;
  ctx.font = 'bold 24px Didot, serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  
  // Wrap text if needed
  const words = text.split(' ');
  const lines = [];
  let currentLine = words[0];
  
  for (let i = 1; i < words.length; i++) {
    const word = words[i];
    const width = ctx.measureText(currentLine + " " + word).width;
    if (width < canvas.width - 40) {
      currentLine += " " + word;
    } else {
      lines.push(currentLine);
      currentLine = word;
    }
  }
  lines.push(currentLine);
  
  // Draw text lines
  const lineHeight = 30;
  const startY = (height / 2) - ((lines.length - 1) * lineHeight / 2);
  
  lines.forEach((line, index) => {
    ctx.fillText(line, width / 2, startY + (index * lineHeight));
  });
  
  // Add "LUXE QUEER" watermark
  ctx.font = 'bold 16px Didot, serif';
  ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
  ctx.fillText('LUXE QUEER', width / 2, height - 20);
  
  // Save the image
  const buffer = canvas.toBuffer('image/jpeg');
  fs.writeFileSync(path.join(outputDir, filename), buffer);
  
  console.log(`Created ${filename}`);
}

// Create founder image
createPlaceholderImage(
  'founder.jpg',
  600,
  800,
  colors.midnightBlue,
  'Levi Hankins Founder, Luxe Queer Magazine'
);

// Create hero images
createPlaceholderImage(
  'home-hero.jpg',
  1200,
  800,
  colors.deepWineRed,
  'LUXE QUEER MAGAZINE'
);

createPlaceholderImage(
  'about-hero.jpg',
  1200,
  600,
  colors.verdigris,
  'ABOUT LUXE QUEER'
);

createPlaceholderImage(
  'features-hero.jpg',
  1200,
  600,
  colors.burnishedGold,
  'FEATURES'
);

createPlaceholderImage(
  'octavia-hero.jpg',
  1200,
  600,
  colors.softLavender,
  'OCTAVIA OPULENCE³'
);

createPlaceholderImage(
  'subscribe-hero.jpg',
  1200,
  600,
  colors.matteBlack,
  'SUBSCRIBE'
);

// Create Octavia images
createPlaceholderImage(
  'octavia-profile.jpg',
  800,
  1000,
  colors.midnightBlue,
  'Octavia Opulence³'
);

// Create Blue Lipstick Edit images
createPlaceholderImage(
  'blue-lipstick-edit.jpg',
  800,
  600,
  colors.blueLipstick,
  'The Blue Lipstick Edit'
);

// Create category images
const categories = ['FASHION', 'ART', 'CULTURE', 'TRAVEL', 'TECHNOLOGY', 'LUXURY'];
categories.forEach(category => {
  createPlaceholderImage(
    `category-${category.toLowerCase()}.jpg`,
    600,
    400,
    colors.deepWineRed,
    category
  );
});

// Create logo image
createPlaceholderImage(
  'logo.jpg',
  400,
  200,
  colors.matteBlack,
  'LUXE QUEER'
);

// Create social sharing image
createPlaceholderImage(
  'luxe-queer-og.jpg',
  1200,
  630,
  colors.deepWineRed,
  'LUXE QUEER MAGAZINE'
);

console.log('All placeholder images have been created successfully.');
