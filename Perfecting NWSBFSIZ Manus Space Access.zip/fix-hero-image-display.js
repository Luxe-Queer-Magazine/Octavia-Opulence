const fs = require('fs');
const path = require('path');
const cheerio = require('cheerio');

// Function to fix the hero image display issue
function fixHeroImageDisplay() {
  console.log('Fixing hero image display issues...');
  
  // Update the CSS to ensure proper display of the hero image
  const cssFilePath = path.join(__dirname, 'css', 'original-style.css');
  
  if (fs.existsSync(cssFilePath)) {
    let cssContent = fs.readFileSync(cssFilePath, 'utf8');
    
    // Update the hero section styling with more specific rules to ensure image display
    cssContent = cssContent.replace(
      /\.hero::before \{[^}]*\}/g,
      `.hero::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-image: url("../images/hero-blue-lipstick.jpg");
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  filter: brightness(0.9);
  z-index: -1;
}`
    );
    
    // Remove any placeholder text that might be showing
    cssContent = cssContent.replace(/LUXE QUEER HERO IMAGE/g, '');
    
    fs.writeFileSync(cssFilePath, cssContent);
    console.log('Updated CSS with fixed hero image styling');
  } else {
    console.log('CSS file not found');
  }
  
  // Update the index.html file to ensure proper hero structure
  const indexFilePath = path.join(__dirname, 'index.html');
  
  if (fs.existsSync(indexFilePath)) {
    console.log('Updating index.html...');
    
    // Read the HTML file
    const html = fs.readFileSync(indexFilePath, 'utf8');
    const $ = cheerio.load(html);
    
    // Update the hero section
    if ($('.hero, .hero-section, #hero').length) {
      // Remove any placeholder text
      $('.hero, .hero-section, #hero').find('img[alt="LUXE QUEER HERO IMAGE"]').remove();
      
      // Make sure the hero has the proper structure
      const $hero = $('.hero, .hero-section, #hero').first();
      $hero.addClass('hero').attr('style', '');
      
      // Ensure hero content is properly structured
      if ($hero.find('.hero-content').length === 0) {
        $hero.wrapInner('<div class="hero-content"></div>');
      }
      
      // Write the updated HTML
      fs.writeFileSync(indexFilePath, $.html());
      console.log('Updated index.html with fixed hero structure');
    }
  }
  
  // Create a direct HTML reference to the image in all hero sections
  const htmlFiles = [
    'index.html',
    'pages/about.html',
    'pages/features.html',
    'pages/octavia.html',
    'pages/subscribe.html'
  ];
  
  for (const htmlFile of htmlFiles) {
    const filePath = path.join(__dirname, htmlFile);
    
    if (fs.existsSync(filePath)) {
      console.log(`Adding direct image reference to ${htmlFile}...`);
      
      // Read the HTML file
      const html = fs.readFileSync(filePath, 'utf8');
      const $ = cheerio.load(html);
      
      // Update the hero section if it exists
      if ($('.hero, .hero-section, #hero').length) {
        const $hero = $('.hero, .hero-section, #hero').first();
        
        // Add a direct img tag reference as a fallback
        if ($hero.find('img.hero-background').length === 0) {
          $hero.prepend('<img src="/images/hero-blue-lipstick.jpg" alt="Blue Lipstick Hero" class="hero-background" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; z-index: -1;">');
        }
        
        // Write the updated HTML
        fs.writeFileSync(filePath, $.html());
      }
    }
  }
  
  // Add additional CSS to ensure the hero image displays properly
  const additionalCSS = `
/* Additional hero image styling to ensure display */
.hero {
  position: relative;
  min-height: 600px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  background-color: #000033; /* Fallback color */
}

.hero-background {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  z-index: -1;
}

.hero-content {
  position: relative;
  z-index: 2;
  max-width: 800px;
  margin: 0 auto;
  text-align: center;
  padding: 0 20px;
  color: white;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
}
`;
  
  fs.appendFileSync(cssFilePath, additionalCSS);
  console.log('Added additional CSS to ensure hero image displays properly');
  
  console.log('Hero image display fixes completed successfully!');
}

// Run the fix
fixHeroImageDisplay();
