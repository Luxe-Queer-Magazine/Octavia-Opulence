const fs = require('fs');
const path = require('path');
const cheerio = require('cheerio');
const { createCanvas, loadImage } = require('canvas');

// Function to remove highlighting from blue lips image and update logo
async function updateBlueElements() {
  console.log('Removing highlighting from blue lips image and updating logo...');
  
  // 1. Update the hero section styling to remove highlighting
  const indexFilePath = path.join(__dirname, 'index.html');
  
  if (fs.existsSync(indexFilePath)) {
    console.log('Updating index.html to remove highlighting...');
    
    // Read the HTML file
    const html = fs.readFileSync(indexFilePath, 'utf8');
    const $ = cheerio.load(html);
    
    // Update the hero section to remove any highlighting
    if ($('.hero, .hero-section, #hero').length) {
      const $hero = $('.hero, .hero-section, #hero').first();
      
      // Remove any highlighting effects from the hero content
      $hero.find('.hero-content h1, .hero-content h2, .hero-content p').css({
        'text-shadow': '1px 1px 2px rgba(0, 0, 0, 0.5)',
        'color': 'white'
      });
      
      // Remove any highlighting spans or elements
      $hero.find('span[style*="color"]').removeAttr('style');
      
      // Write the updated HTML
      fs.writeFileSync(indexFilePath, $.html());
      console.log('Updated index.html to remove highlighting');
    }
  }
  
  // 2. Update all pages to remove highlighting
  const otherPages = [
    'pages/about.html',
    'pages/features.html',
    'pages/octavia.html',
    'pages/subscribe.html'
  ];
  
  for (const pagePath of otherPages) {
    const filePath = path.join(__dirname, pagePath);
    
    if (fs.existsSync(filePath)) {
      console.log(`Updating ${pagePath} to remove highlighting...`);
      
      // Read the HTML file
      const html = fs.readFileSync(filePath, 'utf8');
      const $ = cheerio.load(html);
      
      // Remove any highlighting from headings and text
      $('h1, h2, h3, h4, h5, h6, p, span').each(function() {
        const $el = $(this);
        if ($el.attr('style') && $el.attr('style').includes('color: #00a0ff') || 
            $el.attr('style') && $el.attr('style').includes('color: blue')) {
          $el.removeAttr('style');
        }
      });
      
      // Write the updated HTML
      fs.writeFileSync(filePath, $.html());
      console.log(`Updated ${pagePath} to remove highlighting`);
    }
  }
  
  // 3. Create a new logo with blue lips
  console.log('Creating new logo with blue lips...');
  
  try {
    // Create a canvas for the logo
    const canvas = createCanvas(200, 60);
    const ctx = canvas.getContext('2d');
    
    // Fill background
    ctx.fillStyle = 'transparent';
    ctx.fillRect(0, 0, 200, 60);
    
    // Draw text
    ctx.fillStyle = '#333333';
    ctx.font = 'bold 24px Arial';
    ctx.fillText('LUXE QUEER', 10, 35);
    
    // Draw blue lips icon
    ctx.fillStyle = '#00a0ff'; // Blue color for lips
    
    // Simple lips shape
    ctx.beginPath();
    ctx.moveTo(170, 30);
    ctx.bezierCurveTo(175, 25, 185, 25, 190, 30);
    ctx.bezierCurveTo(185, 40, 175, 40, 170, 30);
    ctx.fill();
    
    // Save the logo
    const buffer = canvas.toBuffer('image/png');
    fs.writeFileSync(path.join(__dirname, 'images', 'logo-blue-lips.png'), buffer);
    console.log('Created new logo with blue lips');
    
    // Update all HTML files to use the new logo
    const allPages = ['index.html', ...otherPages];
    
    for (const pagePath of allPages) {
      const filePath = path.join(__dirname, pagePath);
      
      if (fs.existsSync(filePath)) {
        console.log(`Updating ${pagePath} with new logo...`);
        
        // Read the HTML file
        const html = fs.readFileSync(filePath, 'utf8');
        const $ = cheerio.load(html);
        
        // Update the logo image
        $('header img, .logo img, nav img').attr('src', '/images/logo-blue-lips.png');
        
        // Write the updated HTML
        fs.writeFileSync(filePath, $.html());
        console.log(`Updated ${pagePath} with new logo`);
      }
    }
  } catch (error) {
    console.error('Error creating logo:', error);
  }
  
  // 4. Update CSS to remove any highlighting styles
  const cssFiles = [
    'css/styles.css',
    'css/original-style.css'
  ];
  
  for (const cssFile of cssFiles) {
    const cssPath = path.join(__dirname, cssFile);
    
    if (fs.existsSync(cssPath)) {
      console.log(`Updating ${cssFile} to remove highlighting styles...`);
      
      let cssContent = fs.readFileSync(cssPath, 'utf8');
      
      // Remove highlighting styles
      cssContent = cssContent.replace(/color: #00a0ff;/g, 'color: inherit;');
      cssContent = cssContent.replace(/color: blue;/g, 'color: inherit;');
      
      // Add styles for the new logo
      cssContent += `
/* Updated logo styles */
.logo img, header img {
  max-height: 50px;
  width: auto;
}
`;
      
      fs.writeFileSync(cssPath, cssContent);
      console.log(`Updated ${cssFile} to remove highlighting styles`);
    }
  }
  
  console.log('Successfully removed highlighting from blue lips image and updated logo!');
}

// Run the update
updateBlueElements().catch(console.error);
