const fs = require('fs');
const path = require('path');
const cheerio = require('cheerio');

// Create directories if they don't exist
const imagesDir = path.join(__dirname, 'images');
if (!fs.existsSync(imagesDir)) {
  fs.mkdirSync(imagesDir, { recursive: true });
}

// Function to download the blue lipstick logo and hero image from the original site
async function downloadOriginalImages() {
  console.log('Downloading original images...');
  
  // We'll create placeholder images with the right styling instead of downloading
  // Create blue lipstick logo
  const canvas = require('canvas');
  const logoCanvas = canvas.createCanvas(240, 60);
  const logoCtx = logoCanvas.getContext('2d');
  
  // Draw "LUXE QUEER" text
  logoCtx.font = 'bold 28px serif';
  logoCtx.fillStyle = '#333';
  logoCtx.fillText('LUXE QUEER', 0, 40);
  
  // Draw blue lipstick mark
  logoCtx.beginPath();
  logoCtx.arc(220, 30, 20, 0, Math.PI * 2);
  logoCtx.fillStyle = '#0066ff';
  logoCtx.fill();
  
  // Draw lips shape
  logoCtx.beginPath();
  logoCtx.ellipse(220, 30, 15, 8, 0, 0, Math.PI * 2);
  logoCtx.strokeStyle = 'white';
  logoCtx.lineWidth = 2;
  logoCtx.stroke();
  
  // Save logo
  const logoBuffer = logoCanvas.toBuffer('image/png');
  fs.writeFileSync(path.join(imagesDir, 'logo-with-blue-lipstick.png'), logoBuffer);
  console.log('Created logo with blue lipstick mark');
  
  // Create hero image with model wearing blue lipstick
  const heroCanvas = canvas.createCanvas(1200, 800);
  const heroCtx = heroCanvas.getContext('2d');
  
  // Create gradient background
  const gradient = heroCtx.createLinearGradient(0, 0, 0, 800);
  gradient.addColorStop(0, '#000033');
  gradient.addColorStop(1, '#000066');
  heroCtx.fillStyle = gradient;
  heroCtx.fillRect(0, 0, 1200, 800);
  
  // Add some bokeh effects
  for (let i = 0; i < 100; i++) {
    const x = Math.random() * 1200;
    const y = Math.random() * 800;
    const radius = Math.random() * 20 + 5;
    const opacity = Math.random() * 0.5 + 0.1;
    
    heroCtx.beginPath();
    heroCtx.arc(x, y, radius, 0, Math.PI * 2);
    heroCtx.fillStyle = `rgba(100, 100, 255, ${opacity})`;
    heroCtx.fill();
  }
  
  // Add text placeholder for where model would be
  heroCtx.font = 'bold 40px sans-serif';
  heroCtx.fillStyle = 'white';
  heroCtx.textAlign = 'center';
  heroCtx.fillText('MODEL WITH BLUE LIPSTICK', 600, 400);
  heroCtx.font = '24px sans-serif';
  heroCtx.fillText('Deep blue background with fashion model', 600, 450);
  heroCtx.fillText('wearing signature blue lipstick', 600, 480);
  
  // Save hero image
  const heroBuffer = heroCanvas.toBuffer('image/png');
  fs.writeFileSync(path.join(imagesDir, 'hero-blue-lipstick.png'), heroBuffer);
  console.log('Created hero image placeholder');
}

// Function to update the CSS to match the original site's styling
function updateCSS() {
  console.log('Updating CSS styling...');
  
  const cssContent = `
/* Original site styling */
:root {
  --primary-color: #0066ff; /* Blue lipstick color */
  --dark-blue: #000033;
  --medium-blue: #000066;
  --light-blue: #3399ff;
  --accent-color: #ff00ff; /* Magenta accent */
  --text-color: #333333;
  --light-text: #ffffff;
  --background-color: #f8f8f8;
}

body {
  font-family: 'Helvetica Neue', Arial, sans-serif;
  color: var(--text-color);
  margin: 0;
  padding: 0;
}

/* Header styling */
header {
  padding: 20px 0;
  background-color: white;
}

.logo-container {
  display: flex;
  align-items: center;
}

.logo-container img {
  height: 60px;
}

/* Navigation styling */
nav {
  display: flex;
  justify-content: flex-end;
}

nav a {
  margin-left: 20px;
  color: var(--text-color);
  text-decoration: none;
  font-weight: bold;
  text-transform: uppercase;
  padding: 5px 10px;
  border: 2px solid transparent;
  transition: all 0.3s ease;
}

nav a:hover {
  border-color: var(--primary-color);
  color: var(--primary-color);
}

/* Hero section styling */
.hero {
  background-color: var(--dark-blue);
  color: var(--light-text);
  padding: 100px 0;
  position: relative;
  overflow: hidden;
  background-image: url('../images/hero-blue-lipstick.png');
  background-size: cover;
  background-position: center;
}

.hero-content {
  position: relative;
  z-index: 2;
  max-width: 800px;
  margin: 0 auto;
  text-align: left;
  padding: 0 20px;
}

.hero h1 {
  font-size: 4rem;
  margin-bottom: 20px;
  font-weight: 900;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
}

.hero p {
  font-size: 1.5rem;
  margin-bottom: 30px;
  text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
}

.cta-button {
  display: inline-block;
  background-color: var(--primary-color);
  color: white;
  padding: 12px 30px;
  border-radius: 4px;
  text-decoration: none;
  font-weight: bold;
  text-transform: uppercase;
  transition: all 0.3s ease;
  border: 2px solid var(--primary-color);
}

.cta-button:hover {
  background-color: transparent;
  color: white;
}

/* Section styling */
section {
  padding: 80px 0;
}

section h2 {
  font-size: 2.5rem;
  margin-bottom: 40px;
  text-align: center;
  position: relative;
}

section h2:after {
  content: '';
  display: block;
  width: 80px;
  height: 4px;
  background-color: var(--primary-color);
  position: absolute;
  bottom: -15px;
  left: 50%;
  transform: translateX(-50%);
}

/* Blue lipstick feature */
.blue-lipstick-feature {
  background-color: var(--medium-blue);
  color: white;
  padding: 60px 0;
}

.blue-lipstick-feature h2 {
  color: var(--light-blue);
}

.blue-lipstick-feature h2:after {
  background-color: white;
}

/* Footer styling */
footer {
  background-color: var(--dark-blue);
  color: white;
  padding: 60px 0 30px;
}

footer a {
  color: var(--light-blue);
  text-decoration: none;
}

footer a:hover {
  text-decoration: underline;
}

/* Mobile menu styling */
.hamburger-menu {
  display: none;
  cursor: pointer;
}

@media (max-width: 768px) {
  .hamburger-menu {
    display: block;
  }
  
  nav.desktop-menu {
    display: none;
  }
  
  nav.mobile-menu {
    display: flex;
    flex-direction: column;
    position: absolute;
    top: 80px;
    right: 0;
    background-color: white;
    width: 100%;
    padding: 20px;
    box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
    z-index: 100;
  }
  
  nav.mobile-menu a {
    margin: 10px 0;
    padding: 10px;
    border-bottom: 1px solid #eee;
  }
}
`;

  fs.writeFileSync(path.join(__dirname, 'css', 'original-style.css'), cssContent);
  console.log('Created original-style.css');
}

// Function to update the HTML files with the original styling
async function updateHTMLFiles() {
  console.log('Updating HTML files with original styling...');
  
  // Get all HTML files
  const htmlFiles = [
    'index.html',
    'pages/about.html',
    'pages/features.html',
    'pages/octavia.html',
    'pages/subscribe.html',
    'pages/user-guide.html',
    'pages/terms-of-service.html',
    'pages/privacy-policy.html',
    'pages/sms-opt-in.html',
    'pages/octavia-admin-manual.html',
    'pages/admin-tools-suite.html'
  ];
  
  for (const htmlFile of htmlFiles) {
    const filePath = path.join(__dirname, htmlFile);
    
    if (fs.existsSync(filePath)) {
      console.log(`Updating ${htmlFile}...`);
      
      // Read the HTML file
      const html = fs.readFileSync(filePath, 'utf8');
      const $ = cheerio.load(html);
      
      // Add the original-style.css
      $('head').append('<link rel="stylesheet" href="/css/original-style.css">');
      
      // Update the logo
      $('.navbar-brand, header .logo, .logo').html('<img src="/images/logo-with-blue-lipstick.png" alt="Luxe Queer Magazine">');
      
      // Update hero section if it exists
      if ($('.hero, .hero-section, #hero').length) {
        $('.hero, .hero-section, #hero').addClass('hero').css({
          'background-image': 'url("/images/hero-blue-lipstick.png")',
          'background-size': 'cover',
          'background-position': 'center'
        });
      }
      
      // Add blue lipstick accent to buttons
      $('a.btn-primary, button.btn-primary').addClass('cta-button');
      
      // Write the updated HTML
      fs.writeFileSync(filePath, $.html());
    }
  }
  
  console.log('HTML files updated with original styling');
}

// Main function to update the visual style
async function updateVisualStyle() {
  try {
    console.log('Starting visual style update...');
    
    // Install required packages if not already installed
    try {
      require('canvas');
      require('cheerio');
    } catch (err) {
      console.log('Installing required packages...');
      const { execSync } = require('child_process');
      execSync('npm install canvas cheerio', { stdio: 'inherit' });
    }
    
    // Download/create original images
    await downloadOriginalImages();
    
    // Update CSS
    updateCSS();
    
    // Update HTML files
    await updateHTMLFiles();
    
    console.log('Visual style update completed successfully!');
  } catch (error) {
    console.error('Error updating visual style:', error);
  }
}

// Run the update
updateVisualStyle();
