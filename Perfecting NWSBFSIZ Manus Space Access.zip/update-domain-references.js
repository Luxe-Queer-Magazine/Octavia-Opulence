// Update domain references across all HTML files
const fs = require('fs');
const path = require('path');

// Get all HTML files in the pages directory
const pagesDir = path.join(__dirname, 'pages');
const htmlFiles = fs.readdirSync(pagesDir).filter(file => file.endsWith('.html'));

// Also update the main index.html file
const indexFile = path.join(__dirname, 'index.html');
if (fs.existsSync(indexFile)) {
    htmlFiles.push('../index.html');
}

// Old domain in the current URLs
const oldDomain = 'nwsbfsiz.manus.space';
// New domain to replace with
const newDomain = 'luxequeer.com';

// Process each HTML file
htmlFiles.forEach(file => {
    const filePath = file === '../index.html' ? indexFile : path.join(pagesDir, file);
    let content = fs.readFileSync(filePath, 'utf8');
    
    // Replace all instances of the old domain with the new domain
    if (content.includes(oldDomain)) {
        content = content.replace(new RegExp(oldDomain, 'g'), newDomain);
        
        // Write the updated content back to the file
        fs.writeFileSync(filePath, content);
        console.log(`Updated domain references in ${file}`);
    } else {
        console.log(`No domain references found in ${file}`);
    }
});

console.log('Domain reference update complete!');
