// Fix hamburger menu functionality
const fs = require('fs');
const path = require('path');

// Configuration
const websiteDir = '/home/ubuntu/luxe_queer_website';

// Improved hamburger menu HTML with correct relative paths
const hamburgerMenuHTML = `
    <!-- Hamburger Menu Button -->
    <button class="hamburger-menu" aria-label="Toggle navigation menu" aria-expanded="false">
      <div class="hamburger-line"></div>
      <div class="hamburger-line"></div>
      <div class="hamburger-line"></div>
    </button>
    
    <!-- Mobile Navigation -->
    <div class="mobile-nav">
      <ul>
        <li><a href="about.html">ABOUT</a></li>
        <li><a href="features.html">FEATURES</a></li>
        <li><a href="octavia.html">OCTAVIA</a></li>
        <li><a href="subscribe.html">SUBSCRIBE</a></li>
        <li><a href="user-guide.html">USER GUIDE</a></li>
        <li><a href="privacy-policy.html">PRIVACY</a></li>
        <li><a href="terms-of-service.html">TERMS</a></li>
      </ul>
    </div>`;

// Main index page hamburger menu with correct paths to pages directory
const indexHamburgerMenuHTML = `
    <!-- Hamburger Menu Button -->
    <button class="hamburger-menu" aria-label="Toggle navigation menu" aria-expanded="false">
      <div class="hamburger-line"></div>
      <div class="hamburger-line"></div>
      <div class="hamburger-line"></div>
    </button>
    
    <!-- Mobile Navigation -->
    <div class="mobile-nav">
      <ul>
        <li><a href="pages/about.html">ABOUT</a></li>
        <li><a href="pages/features.html">FEATURES</a></li>
        <li><a href="pages/octavia.html">OCTAVIA</a></li>
        <li><a href="pages/subscribe.html">SUBSCRIBE</a></li>
        <li><a href="pages/user-guide.html">USER GUIDE</a></li>
        <li><a href="pages/privacy-policy.html">PRIVACY</a></li>
        <li><a href="pages/terms-of-service.html">TERMS</a></li>
      </ul>
    </div>`;

// Get all HTML files
function getAllHtmlFiles(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  
  list.forEach(file => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    
    if (stat.isDirectory() && file !== 'node_modules' && file !== 'build') {
      results = results.concat(getAllHtmlFiles(filePath));
    } else if (file.endsWith('.html') && file !== 'footer-template.html' && file !== 'updated-footer-template.html') {
      results.push(filePath);
    }
  });
  
  return results;
}

const htmlFiles = getAllHtmlFiles(websiteDir);
console.log(`Found ${htmlFiles.length} HTML files to update with fixed hamburger menu`);

// Update each HTML file
htmlFiles.forEach(filePath => {
  console.log(`Fixing hamburger menu in ${filePath}`);
  
  // Read file content
  let content = fs.readFileSync(filePath, 'utf8');
  
  // Remove existing hamburger menu if present
  const hamburgerButtonRegex = /<button class="hamburger-menu"[\s\S]*?<\/button>/;
  const mobileNavRegex = /<div class="mobile-nav">[\s\S]*?<\/div>/;
  
  if (hamburgerButtonRegex.test(content) && mobileNavRegex.test(content)) {
    content = content.replace(hamburgerButtonRegex, '');
    content = content.replace(mobileNavRegex, '');
    console.log(`Removed existing hamburger menu from ${filePath}`);
  }
  
  // Add improved hamburger menu after the nav element
  const navRegex = /<\/nav>/;
  if (navRegex.test(content)) {
    // Use index-specific menu for the main index.html file
    if (filePath.endsWith('index.html')) {
      content = content.replace(navRegex, '</nav>' + indexHamburgerMenuHTML);
    } else {
      content = content.replace(navRegex, '</nav>' + hamburgerMenuHTML);
    }
  } else {
    console.warn(`No nav element found in ${filePath}`);
  }
  
  // Ensure CSS link for hamburger menu is present
  if (!content.includes('hamburger-menu.css')) {
    const headEndRegex = /<\/head>/;
    // Use relative path based on file location
    const cssLink = filePath.includes('/pages/') 
      ? `    <link rel="stylesheet" href="../css/hamburger-menu.css">\n</head>`
      : `    <link rel="stylesheet" href="css/hamburger-menu.css">\n</head>`;
    content = content.replace(headEndRegex, cssLink);
  }
  
  // Ensure JavaScript for hamburger menu is present
  if (!content.includes('hamburger-menu.js')) {
    const bodyEndRegex = /<\/body>/;
    // Use relative path based on file location
    const jsScript = filePath.includes('/pages/') 
      ? `    <script src="../js/hamburger-menu.js"></script>\n</body>`
      : `    <script src="js/hamburger-menu.js"></script>\n</body>`;
    content = content.replace(bodyEndRegex, jsScript);
  }
  
  // Write updated content back to file
  fs.writeFileSync(filePath, content);
});

// Fix the hamburger menu CSS to ensure it works properly
const hamburgerCssPath = path.join(websiteDir, 'css', 'hamburger-menu.css');
let hamburgerCss = fs.readFileSync(hamburgerCssPath, 'utf8');

// Fix the mobile-nav display issue - it should be block but hidden by transform
const updatedCss = hamburgerCss.replace(
  '.mobile-nav {\n  display: none;',
  '.mobile-nav {\n  display: block;'
);

fs.writeFileSync(hamburgerCssPath, updatedCss);
console.log('Updated hamburger-menu.css to fix display issue');

// Update the hamburger menu JavaScript to ensure it works properly
const hamburgerJsPath = path.join(websiteDir, 'js', 'hamburger-menu.js');
let hamburgerJs = fs.readFileSync(hamburgerJsPath, 'utf8');

// Add a console log to help with debugging
const updatedJs = hamburgerJs.replace(
  'document.addEventListener(\'DOMContentLoaded\', function() {',
  'document.addEventListener(\'DOMContentLoaded\', function() {\n  console.log("Hamburger menu script loaded");'
);

fs.writeFileSync(hamburgerJsPath, updatedJs);
console.log('Updated hamburger-menu.js with debugging information');

console.log('Hamburger menu fixes complete!');
