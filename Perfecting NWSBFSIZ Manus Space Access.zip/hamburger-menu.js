// Hamburger menu functionality
document.addEventListener('DOMContentLoaded', function() {
  // Get hamburger menu elements
  const hamburgerMenu = document.querySelector('.hamburger-menu');
  const mobileNav = document.querySelector('.mobile-nav');
  const mobileNavLinks = document.querySelectorAll('.mobile-nav a');
  
  // Toggle mobile navigation when hamburger is clicked
  if (hamburgerMenu) {
    hamburgerMenu.addEventListener('click', function() {
      hamburgerMenu.classList.toggle('open');
      mobileNav.classList.toggle('open');
      
      // Toggle aria-expanded attribute for accessibility
      const expanded = hamburgerMenu.getAttribute('aria-expanded') === 'true' || false;
      hamburgerMenu.setAttribute('aria-expanded', !expanded);
      
      // Toggle body scroll
      if (mobileNav.classList.contains('open')) {
        document.body.style.overflow = 'hidden'; // Prevent scrolling when menu is open
      } else {
        document.body.style.overflow = ''; // Restore scrolling when menu is closed
      }
    });
  }
  
  // Close mobile navigation when a link is clicked
  if (mobileNavLinks) {
    mobileNavLinks.forEach(link => {
      link.addEventListener('click', function() {
        hamburgerMenu.classList.remove('open');
        mobileNav.classList.remove('open');
        document.body.style.overflow = ''; // Restore scrolling
        hamburgerMenu.setAttribute('aria-expanded', 'false');
      });
    });
  }
  
  // Close mobile navigation when clicking outside
  document.addEventListener('click', function(event) {
    if (mobileNav && mobileNav.classList.contains('open') && 
        !mobileNav.contains(event.target) && 
        !hamburgerMenu.contains(event.target)) {
      hamburgerMenu.classList.remove('open');
      mobileNav.classList.remove('open');
      document.body.style.overflow = ''; // Restore scrolling
      hamburgerMenu.setAttribute('aria-expanded', 'false');
    }
  });
  
  // Handle window resize
  window.addEventListener('resize', function() {
    if (window.innerWidth > 768 && mobileNav && mobileNav.classList.contains('open')) {
      hamburgerMenu.classList.remove('open');
      mobileNav.classList.remove('open');
      document.body.style.overflow = ''; // Restore scrolling
      hamburgerMenu.setAttribute('aria-expanded', 'false');
    }
  });
});
