// Update footer across all pages
const fs = require('fs');
const path = require('path');

// Read the updated footer template
const updatedFooter = fs.readFileSync(path.join(__dirname, 'pages', 'updated-footer-template.html'), 'utf8');

// Get all HTML files in the pages directory
const pagesDir = path.join(__dirname, 'pages');
const htmlFiles = fs.readdirSync(pagesDir).filter(file => file.endsWith('.html') && file !== 'updated-footer-template.html');

// Also update the main index.html file
const indexFile = path.join(__dirname, 'index.html');
if (fs.existsSync(indexFile)) {
    htmlFiles.push('../index.html');
}

// Process each HTML file
htmlFiles.forEach(file => {
    const filePath = file === '../index.html' ? indexFile : path.join(pagesDir, file);
    let content = fs.readFileSync(filePath, 'utf8');
    
    // Replace the existing footer with the updated one
    // Look for the footer tag and replace everything between opening and closing footer tags
    const footerRegex = /<footer>[\s\S]*?<\/footer>/;
    
    if (footerRegex.test(content)) {
        content = content.replace(footerRegex, updatedFooter);
        
        // Write the updated content back to the file
        fs.writeFileSync(filePath, content);
        console.log(`Updated footer in ${file}`);
    } else {
        console.log(`No footer found in ${file}`);
    }
});

console.log('Footer update complete!');
