// Test all website functionality
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const { promisify } = require('util');
const execAsync = promisify(exec);

// Configuration
const websiteDir = '/home/ubuntu/luxe_queer_website';
const testReportDir = path.join(websiteDir, 'testing_report');
const testReportPath = path.join(testReportDir, 'final_testing_report.md');

// Ensure test report directory exists
if (!fs.existsSync(testReportDir)) {
  fs.mkdirSync(testReportDir, { recursive: true });
}

// Get all HTML files
function getAllHtmlFiles(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  
  list.forEach(file => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    
    if (stat.isDirectory() && file !== 'node_modules' && file !== 'build') {
      results = results.concat(getAllHtmlFiles(filePath));
    } else if (file.endsWith('.html') && !file.includes('template')) {
      results.push(filePath);
    }
  });
  
  return results;
}

// Test HTML validity
async function testHtmlValidity(htmlFiles) {
  console.log('Testing HTML validity...');
  
  const results = {
    valid: [],
    invalid: []
  };
  
  for (const file of htmlFiles) {
    try {
      // Use html-validator CLI if available, otherwise just check for basic HTML structure
      const content = fs.readFileSync(file, 'utf8');
      const hasHtmlTag = content.includes('<html');
      const hasHeadTag = content.includes('<head');
      const hasBodyTag = content.includes('<body');
      const hasClosingTags = content.includes('</html>') && content.includes('</head>') && content.includes('</body>');
      
      if (hasHtmlTag && hasHeadTag && hasBodyTag && hasClosingTags) {
        results.valid.push(path.relative(websiteDir, file));
      } else {
        results.invalid.push({
          file: path.relative(websiteDir, file),
          issues: [
            !hasHtmlTag ? 'Missing <html> tag' : null,
            !hasHeadTag ? 'Missing <head> tag' : null,
            !hasBodyTag ? 'Missing <body> tag' : null,
            !hasClosingTags ? 'Missing closing tags' : null
          ].filter(Boolean)
        });
      }
    } catch (error) {
      results.invalid.push({
        file: path.relative(websiteDir, file),
        issues: [`Error reading file: ${error.message}`]
      });
    }
  }
  
  return results;
}

// Test CSS validity
async function testCssValidity() {
  console.log('Testing CSS validity...');
  
  const cssDir = path.join(websiteDir, 'css');
  const cssFiles = fs.readdirSync(cssDir).filter(file => file.endsWith('.css'));
  
  const results = {
    valid: [],
    invalid: []
  };
  
  for (const file of cssFiles) {
    try {
      const filePath = path.join(cssDir, file);
      const content = fs.readFileSync(filePath, 'utf8');
      
      // Basic CSS validation - check for matching braces
      const openBraces = (content.match(/{/g) || []).length;
      const closeBraces = (content.match(/}/g) || []).length;
      
      if (openBraces === closeBraces) {
        results.valid.push(file);
      } else {
        results.invalid.push({
          file,
          issues: [`Mismatched braces: ${openBraces} opening vs ${closeBraces} closing`]
        });
      }
    } catch (error) {
      results.invalid.push({
        file,
        issues: [`Error reading file: ${error.message}`]
      });
    }
  }
  
  return results;
}

// Test JavaScript validity
async function testJsValidity() {
  console.log('Testing JavaScript validity...');
  
  const jsDir = path.join(websiteDir, 'js');
  const jsFiles = fs.readdirSync(jsDir).filter(file => file.endsWith('.js'));
  
  const results = {
    valid: [],
    invalid: []
  };
  
  for (const file of jsFiles) {
    try {
      const filePath = path.join(jsDir, file);
      
      // Use Node.js to check for syntax errors
      try {
        await execAsync(`node --check "${filePath}"`);
        results.valid.push(file);
      } catch (error) {
        results.invalid.push({
          file,
          issues: [error.stderr.trim()]
        });
      }
    } catch (error) {
      results.invalid.push({
        file,
        issues: [`Error processing file: ${error.message}`]
      });
    }
  }
  
  return results;
}

// Test image references
async function testImageReferences(htmlFiles) {
  console.log('Testing image references...');
  
  const results = {
    valid: [],
    invalid: []
  };
  
  const imagesDir = path.join(websiteDir, 'images');
  const availableImages = fs.readdirSync(imagesDir);
  
  for (const file of htmlFiles) {
    try {
      const content = fs.readFileSync(file, 'utf8');
      const imgRegex = /<img[^>]+src=["']([^"']+)["']/g;
      let match;
      const missingImages = [];
      
      while ((match = imgRegex.exec(content)) !== null) {
        const imgSrc = match[1];
        
        // Skip external images
        if (imgSrc.startsWith('http')) continue;
        
        // Extract image filename
        const imgFilename = path.basename(imgSrc);
        
        if (!availableImages.includes(imgFilename)) {
          missingImages.push(imgSrc);
        }
      }
      
      if (missingImages.length === 0) {
        results.valid.push(path.relative(websiteDir, file));
      } else {
        results.invalid.push({
          file: path.relative(websiteDir, file),
          issues: missingImages.map(img => `Missing image: ${img}`)
        });
      }
    } catch (error) {
      results.invalid.push({
        file: path.relative(websiteDir, file),
        issues: [`Error reading file: ${error.message}`]
      });
    }
  }
  
  return results;
}

// Test links
async function testLinks(htmlFiles) {
  console.log('Testing links...');
  
  const results = {
    valid: [],
    invalid: []
  };
  
  const validPages = htmlFiles.map(file => {
    const relativePath = path.relative(websiteDir, file);
    return relativePath.replace(/\\/g, '/');
  });
  
  for (const file of htmlFiles) {
    try {
      const content = fs.readFileSync(file, 'utf8');
      const linkRegex = /<a[^>]+href=["']([^"']+)["']/g;
      let match;
      const brokenLinks = [];
      
      while ((match = linkRegex.exec(content)) !== null) {
        const href = match[1];
        
        // Skip external links, anchors, and javascript links
        if (href.startsWith('http') || href.startsWith('#') || href.startsWith('javascript:') || href.startsWith('mailto:')) continue;
        
        // Normalize path
        let normalizedHref = href;
        if (href.startsWith('/')) {
          normalizedHref = href.substring(1);
        }
        
        // Check if the link points to a valid page
        const isValid = validPages.some(page => {
          return page === normalizedHref || 
                 page.endsWith('/' + normalizedHref) || 
                 normalizedHref.endsWith(page);
        });
        
        if (!isValid) {
          brokenLinks.push(href);
        }
      }
      
      if (brokenLinks.length === 0) {
        results.valid.push(path.relative(websiteDir, file));
      } else {
        results.invalid.push({
          file: path.relative(websiteDir, file),
          issues: brokenLinks.map(link => `Broken link: ${link}`)
        });
      }
    } catch (error) {
      results.invalid.push({
        file: path.relative(websiteDir, file),
        issues: [`Error reading file: ${error.message}`]
      });
    }
  }
  
  return results;
}

// Test hamburger menu
async function testHamburgerMenu(htmlFiles) {
  console.log('Testing hamburger menu...');
  
  const results = {
    valid: [],
    invalid: []
  };
  
  for (const file of htmlFiles) {
    try {
      const content = fs.readFileSync(file, 'utf8');
      
      // Skip files that don't need a hamburger menu (like documentation files)
      if (file.includes('/documentation/') || file.includes('/testing_report/') || file.includes('/validation_report/')) {
        continue;
      }
      
      const hasHamburgerButton = content.includes('hamburger-menu');
      const hasMobileNav = content.includes('mobile-nav');
      const hasHamburgerCss = content.includes('hamburger-menu.css');
      const hasHamburgerJs = content.includes('hamburger-menu.js');
      
      if (hasHamburgerButton && hasMobileNav && hasHamburgerCss && hasHamburgerJs) {
        results.valid.push(path.relative(websiteDir, file));
      } else {
        results.invalid.push({
          file: path.relative(websiteDir, file),
          issues: [
            !hasHamburgerButton ? 'Missing hamburger menu button' : null,
            !hasMobileNav ? 'Missing mobile navigation' : null,
            !hasHamburgerCss ? 'Missing hamburger menu CSS' : null,
            !hasHamburgerJs ? 'Missing hamburger menu JavaScript' : null
          ].filter(Boolean)
        });
      }
    } catch (error) {
      results.invalid.push({
        file: path.relative(websiteDir, file),
        issues: [`Error reading file: ${error.message}`]
      });
    }
  }
  
  return results;
}

// Test footer
async function testFooter(htmlFiles) {
  console.log('Testing footer...');
  
  const results = {
    valid: [],
    invalid: []
  };
  
  for (const file of htmlFiles) {
    try {
      const content = fs.readFileSync(file, 'utf8');
      
      // Skip files that don't need a footer (like documentation files)
      if (file.includes('/documentation/') || file.includes('/testing_report/') || file.includes('/validation_report/')) {
        continue;
      }
      
      const hasFooter = content.includes('<footer');
      const hasFooterLogo = content.includes('footer-logo');
      const hasFooterColumns = content.includes('footer-columns');
      const hasFooterNewsletter = content.includes('footer-newsletter');
      const hasFooterLegal = content.includes('footer-legal');
      
      if (hasFooter && hasFooterLogo && hasFooterColumns && hasFooterNewsletter && hasFooterLegal) {
        results.valid.push(path.relative(websiteDir, file));
      } else {
        results.invalid.push({
          file: path.relative(websiteDir, file),
          issues: [
            !hasFooter ? 'Missing footer' : null,
            !hasFooterLogo ? 'Missing footer logo' : null,
            !hasFooterColumns ? 'Missing footer columns' : null,
            !hasFooterNewsletter ? 'Missing footer newsletter' : null,
            !hasFooterLegal ? 'Missing footer legal section' : null
          ].filter(Boolean)
        });
      }
    } catch (error) {
      results.invalid.push({
        file: path.relative(websiteDir, file),
        issues: [`Error reading file: ${error.message}`]
      });
    }
  }
  
  return results;
}

// Generate test report
async function generateTestReport(results) {
  console.log('Generating test report...');
  
  let report = `# Luxe Queer Magazine Website Testing Report\n\n`;
  report += `*Generated on ${new Date().toLocaleString()}*\n\n`;
  
  report += `## Summary\n\n`;
  
  const totalTests = Object.keys(results).length;
  const passedTests = Object.values(results).filter(result => result.invalid.length === 0).length;
  const failedTests = totalTests - passedTests;
  
  report += `- **Total Tests:** ${totalTests}\n`;
  report += `- **Passed Tests:** ${passedTests}\n`;
  report += `- **Failed Tests:** ${failedTests}\n\n`;
  
  if (failedTests === 0) {
    report += `🎉 **All tests passed successfully!** 🎉\n\n`;
  } else {
    report += `⚠️ **Some tests failed. See details below.** ⚠️\n\n`;
  }
  
  // Add detailed results for each test
  for (const [testName, result] of Object.entries(results)) {
    report += `## ${testName.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}\n\n`;
    
    if (result.invalid.length === 0) {
      report += `✅ **All ${result.valid.length} files passed this test.**\n\n`;
    } else {
      report += `❌ **${result.invalid.length} files failed this test:**\n\n`;
      
      result.invalid.forEach(item => {
        report += `### ${item.file}\n\n`;
        item.issues.forEach(issue => {
          report += `- ${issue}\n`;
        });
        report += `\n`;
      });
    }
    
    report += `### Passed Files\n\n`;
    if (result.valid.length > 0) {
      result.valid.forEach(file => {
        report += `- ${file}\n`;
      });
    } else {
      report += `- None\n`;
    }
    
    report += `\n`;
  }
  
  // Add recommendations
  report += `## Recommendations\n\n`;
  
  if (failedTests === 0) {
    report += `The website is functioning correctly and ready for deployment. No further actions are needed.\n\n`;
  } else {
    report += `The following actions are recommended to fix the issues found during testing:\n\n`;
    
    for (const [testName, result] of Object.entries(results)) {
      if (result.invalid.length > 0) {
        report += `### ${testName.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}\n\n`;
        
        const uniqueIssues = new Set();
        result.invalid.forEach(item => {
          item.issues.forEach(issue => {
            uniqueIssues.add(issue);
          });
        });
        
        Array.from(uniqueIssues).forEach(issue => {
          report += `- Fix: ${issue}\n`;
        });
        
        report += `\n`;
      }
    }
  }
  
  fs.writeFileSync(testReportPath, report);
  console.log(`Test report generated at ${testReportPath}`);
  
  return {
    totalTests,
    passedTests,
    failedTests,
    reportPath: testReportPath
  };
}

// Main function
async function runTests() {
  console.log('Starting website testing...');
  
  const htmlFiles = getAllHtmlFiles(websiteDir);
  console.log(`Found ${htmlFiles.length} HTML files to test`);
  
  const results = {
    htmlValidity: await testHtmlValidity(htmlFiles),
    cssValidity: await testCssValidity(),
    jsValidity: await testJsValidity(),
    imageReferences: await testImageReferences(htmlFiles),
    links: await testLinks(htmlFiles),
    hamburgerMenu: await testHamburgerMenu(htmlFiles),
    footer: await testFooter(htmlFiles)
  };
  
  const summary = await generateTestReport(results);
  
  console.log(`Testing complete: ${summary.passedTests}/${summary.totalTests} tests passed`);
  
  return summary;
}

// Run the tests
runTests()
  .then(summary => {
    console.log(`Test report available at: ${summary.reportPath}`);
    
    if (summary.failedTests === 0) {
      console.log('All tests passed! The website is ready for deployment.');
    } else {
      console.log(`${summary.failedTests} tests failed. Please check the test report for details.`);
    }
  })
  .catch(error => {
    console.error('Error running tests:', error);
  });
