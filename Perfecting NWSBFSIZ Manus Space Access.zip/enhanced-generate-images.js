// Enhanced image generation script for Luxe Queer Magazine website
const fs = require('fs');
const path = require('path');
const { createCanvas, loadImage } = require('canvas');

// Configuration
const outputDir = path.join(__dirname, 'images');
const colors = {
  deepWineRed: '#800020',
  midnightBlue: '#191970',
  verdigris: '#43B3AE',
  burnishedGold: '#DAA520',
  softLavender: '#E6E6FA',
  matteBlack: '#28282B',
  blueLipstick: '#1e90ff'
};

// Ensure output directory exists
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}

// Helper function to create a gradient background
function createGradientBackground(ctx, width, height, color1, color2) {
  const gradient = ctx.createLinearGradient(0, 0, width, height);
  gradient.addColorStop(0, color1);
  gradient.addColorStop(1, color2);
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);
}

// Helper function to create a more sophisticated placeholder image
function createEnhancedPlaceholderImage(filename, width, height, bgColor1, bgColor2, text, textColor = '#FFFFFF') {
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  
  // Gradient Background
  createGradientBackground(ctx, width, height, bgColor1, bgColor2);
  
  // Blue lipstick accent - diagonal line
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(width * 0.2, 0);
  ctx.lineTo(0, height * 0.2);
  ctx.closePath();
  ctx.fillStyle = colors.blueLipstick;
  ctx.fill();
  
  // Add some decorative elements
  ctx.beginPath();
  ctx.arc(width * 0.85, height * 0.15, width * 0.1, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
  ctx.fill();
  
  // Add a subtle pattern
  for (let i = 0; i < width; i += 40) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, height);
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
    ctx.stroke();
  }
  
  // Text with shadow
  ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
  ctx.shadowBlur = 15;
  ctx.shadowOffsetX = 5;
  ctx.shadowOffsetY = 5;
  ctx.fillStyle = textColor;
  ctx.font = 'bold 36px "Didot", serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  
  // Wrap text if needed
  const words = text.split(' ');
  const lines = [];
  let currentLine = words[0];
  
  for (let i = 1; i < words.length; i++) {
    const word = words[i];
    const width = ctx.measureText(currentLine + " " + word).width;
    if (width < canvas.width - 80) {
      currentLine += " " + word;
    } else {
      lines.push(currentLine);
      currentLine = word;
    }
  }
  lines.push(currentLine);
  
  // Draw text lines
  const lineHeight = 50;
  const startY = (height / 2) - ((lines.length - 1) * lineHeight / 2);
  
  lines.forEach((line, index) => {
    ctx.fillText(line, width / 2, startY + (index * lineHeight));
  });
  
  // Reset shadow for the watermark
  ctx.shadowColor = 'transparent';
  ctx.shadowBlur = 0;
  ctx.shadowOffsetX = 0;
  ctx.shadowOffsetY = 0;
  
  // Add "LUXE QUEER" watermark
  ctx.font = 'bold 24px "Didot", serif';
  ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
  ctx.fillText('LUXE QUEER', width / 2, height - 30);
  
  // Save the image
  const buffer = canvas.toBuffer('image/jpeg', { quality: 0.95 });
  fs.writeFileSync(path.join(outputDir, filename), buffer);
  
  console.log(`Created enhanced ${filename}`);
}

// Create founder image - more professional looking
createEnhancedPlaceholderImage(
  'founder.jpg',
  600,
  800,
  colors.midnightBlue,
  '#000033',
  'Levi Hankins Founder & CEO',
  '#FFFFFF'
);

// Create hero images with gradients
createEnhancedPlaceholderImage(
  'home-hero.jpg',
  1200,
  800,
  colors.deepWineRed,
  '#400010',
  'LUXE QUEER MAGAZINE',
  '#FFFFFF'
);

createEnhancedPlaceholderImage(
  'about-hero.jpg',
  1200,
  600,
  colors.verdigris,
  '#2A7A76',
  'ABOUT LUXE QUEER',
  '#FFFFFF'
);

createEnhancedPlaceholderImage(
  'features-hero.jpg',
  1200,
  600,
  colors.burnishedGold,
  '#8B6914',
  'FEATURES',
  '#FFFFFF'
);

createEnhancedPlaceholderImage(
  'octavia-hero.jpg',
  1200,
  600,
  colors.softLavender,
  '#9370DB',
  'OCTAVIA OPULENCE³',
  '#FFFFFF'
);

createEnhancedPlaceholderImage(
  'subscribe-hero.jpg',
  1200,
  600,
  colors.matteBlack,
  '#000000',
  'SUBSCRIBE',
  '#FFFFFF'
);

// Create Octavia images
createEnhancedPlaceholderImage(
  'octavia-profile.jpg',
  800,
  1000,
  colors.midnightBlue,
  '#000033',
  'Octavia Opulence³',
  '#FFFFFF'
);

// Create Blue Lipstick Edit images
createEnhancedPlaceholderImage(
  'blue-lipstick-edit.jpg',
  800,
  600,
  colors.blueLipstick,
  '#0077BE',
  'The Blue Lipstick Edit',
  '#FFFFFF'
);

// Create category images with different color schemes
const categories = [
  { name: 'FASHION', color1: '#FF1493', color2: '#C71585' },
  { name: 'ART', color1: '#4B0082', color2: '#2E0854' },
  { name: 'CULTURE', color1: '#20B2AA', color2: '#008B8B' },
  { name: 'TRAVEL', color1: '#6495ED', color2: '#4169E1' },
  { name: 'TECHNOLOGY', color1: '#708090', color2: '#2F4F4F' },
  { name: 'LUXURY', color1: '#B8860B', color2: '#8B4513' }
];

categories.forEach(category => {
  createEnhancedPlaceholderImage(
    `category-${category.name.toLowerCase()}.jpg`,
    600,
    400,
    category.color1,
    category.color2,
    category.name,
    '#FFFFFF'
  );
});

// Create logo image
createEnhancedPlaceholderImage(
  'logo.jpg',
  400,
  200,
  colors.matteBlack,
  '#000000',
  'LUXE QUEER',
  '#FFFFFF'
);

// Create social sharing image
createEnhancedPlaceholderImage(
  'luxe-queer-og.jpg',
  1200,
  630,
  colors.deepWineRed,
  '#400010',
  'LUXE QUEER MAGAZINE',
  '#FFFFFF'
);

console.log('All enhanced placeholder images have been created successfully.');
