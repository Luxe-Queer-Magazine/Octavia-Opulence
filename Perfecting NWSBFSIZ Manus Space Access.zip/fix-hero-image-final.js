const fs = require('fs');
const path = require('path');
const cheerio = require('cheerio');

// Function to fix the hero image display issue with a more direct approach
function fixHeroImageDisplayFinal() {
  console.log('Implementing final hero image display fixes...');
  
  // Update the index.html file to directly embed the hero image
  const indexFilePath = path.join(__dirname, 'index.html');
  
  if (fs.existsSync(indexFilePath)) {
    console.log('Updating index.html with direct hero image...');
    
    // Read the HTML file
    const html = fs.readFileSync(indexFilePath, 'utf8');
    const $ = cheerio.load(html);
    
    // Replace the hero section with a more direct implementation
    if ($('.hero, .hero-section, #hero').length) {
      const $hero = $('.hero, .hero-section, #hero').first();
      
      // Create a completely new hero section with the blue lips image directly embedded
      const newHeroHtml = `
      <section class="hero" style="position: relative; height: 100vh; min-height: 600px; display: flex; align-items: center; justify-content: center; overflow: hidden;">
        <img src="/images/hero-blue-lipstick.jpg" alt="Blue Lipstick Hero" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; z-index: -1;">
        <div class="hero-content" style="position: relative; z-index: 2; max-width: 800px; margin: 0 auto; text-align: center; padding: 0 20px; color: white; text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);">
          <h1>Luxury Redefined</h1>
          <h2>Where queer brilliance meets luxury <span style="color: #00a0ff;">and</span><br>
          <span style="color: #00a0ff;">leaves its mark</span></h2>
          <p>Where queer brilliance meets luxury, and neither will ever be the same.</p>
        </div>
      </section>
      `;
      
      // Replace the existing hero section
      $hero.replaceWith(newHeroHtml);
      
      // Write the updated HTML
      fs.writeFileSync(indexFilePath, $.html());
      console.log('Updated index.html with direct hero image implementation');
    }
  }
  
  // Do the same for other main pages
  const otherPages = [
    'pages/about.html',
    'pages/features.html',
    'pages/subscribe.html'
  ];
  
  for (const pagePath of otherPages) {
    const filePath = path.join(__dirname, pagePath);
    
    if (fs.existsSync(filePath)) {
      console.log(`Updating ${pagePath} with direct hero image...`);
      
      // Read the HTML file
      const html = fs.readFileSync(filePath, 'utf8');
      const $ = cheerio.load(html);
      
      // Replace the hero section if it exists
      if ($('.hero, .hero-section, #hero').length) {
        const $hero = $('.hero, .hero-section, #hero').first();
        
        // Create a new hero section with the blue lips image directly embedded
        const pageTitle = pagePath.includes('about') ? 'About Luxe Queer' : 
                         pagePath.includes('features') ? 'Luxe Queer Features' : 'Subscribe to Luxe Queer';
        
        const newHeroHtml = `
        <section class="hero" style="position: relative; height: 50vh; min-height: 400px; display: flex; align-items: center; justify-content: center; overflow: hidden;">
          <img src="/images/hero-blue-lipstick.jpg" alt="Blue Lipstick Hero" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; z-index: -1;">
          <div class="hero-content" style="position: relative; z-index: 2; max-width: 800px; margin: 0 auto; text-align: center; padding: 0 20px; color: white; text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);">
            <h1>${pageTitle}</h1>
          </div>
        </section>
        `;
        
        // Replace the existing hero section
        $hero.replaceWith(newHeroHtml);
        
        // Write the updated HTML
        fs.writeFileSync(filePath, $.html());
        console.log(`Updated ${pagePath} with direct hero image implementation`);
      }
    }
  }
  
  // Special treatment for the Octavia page to highlight the blue lipstick theme
  const octaviaFilePath = path.join(__dirname, 'pages', 'octavia.html');
  
  if (fs.existsSync(octaviaFilePath)) {
    console.log('Enhancing Octavia page with prominent blue lipstick theme...');
    
    // Read the HTML file
    const html = fs.readFileSync(octaviaFilePath, 'utf8');
    const $ = cheerio.load(html);
    
    // Replace the hero section if it exists
    if ($('.hero, .hero-section, #hero').length) {
      const $hero = $('.hero, .hero-section, #hero').first();
      
      // Create a special hero section for Octavia with the blue lips image
      const newHeroHtml = `
      <section class="hero" style="position: relative; height: 60vh; min-height: 500px; display: flex; align-items: center; justify-content: center; overflow: hidden;">
        <img src="/images/hero-blue-lipstick.jpg" alt="Octavia with Blue Lipstick" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; z-index: -1;">
        <div class="hero-content" style="position: relative; z-index: 2; max-width: 800px; margin: 0 auto; text-align: center; padding: 0 20px; color: white; text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);">
          <h1>Meet Octavia Opulence³</h1>
          <h2>The Voice Behind the Blue Lipstick</h2>
        </div>
      </section>
      `;
      
      // Replace the existing hero section
      $hero.replaceWith(newHeroHtml);
      
      // Write the updated HTML
      fs.writeFileSync(octaviaFilePath, $.html());
      console.log('Enhanced Octavia page with prominent blue lipstick theme');
    }
  }
  
  console.log('Final hero image display fixes completed successfully!');
}

// Run the fix
fixHeroImageDisplayFinal();
