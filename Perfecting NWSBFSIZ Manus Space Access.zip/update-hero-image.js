const fs = require('fs');
const path = require('path');
const cheerio = require('cheerio');

// Function to update the hero image in CSS
function updateHeroImageInCSS() {
  console.log('Updating hero image in CSS...');
  
  // Update the original-style.css file
  const cssFilePath = path.join(__dirname, 'css', 'original-style.css');
  
  if (fs.existsSync(cssFilePath)) {
    let cssContent = fs.readFileSync(cssFilePath, 'utf8');
    
    // Update the hero section styling to use the actual image
    cssContent = cssContent.replace(
      /background-image: url\(['"]?\.\.\/images\/hero-blue-lipstick\.png['"]?\);/g,
      'background-image: url("../images/hero-blue-lipstick.jpg");'
    );
    
    // Add specific styling for the hero image
    cssContent += `
/* Enhanced hero image styling */
.hero {
  position: relative;
  height: 100vh;
  min-height: 600px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

.hero::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-image: url("../images/hero-blue-lipstick.jpg");
  background-size: cover;
  background-position: center;
  filter: brightness(0.8);
  z-index: -1;
}

.hero-content {
  position: relative;
  z-index: 2;
  max-width: 800px;
  margin: 0 auto;
  text-align: center;
  padding: 0 20px;
  color: white;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
}

.hero h1 {
  font-size: 4.5rem;
  margin-bottom: 20px;
  font-weight: 900;
}

.hero p {
  font-size: 1.8rem;
  margin-bottom: 30px;
}

@media (max-width: 768px) {
  .hero {
    min-height: 500px;
  }
  
  .hero h1 {
    font-size: 3rem;
  }
  
  .hero p {
    font-size: 1.4rem;
  }
}
`;
    
    fs.writeFileSync(cssFilePath, cssContent);
    console.log('Updated CSS with new hero image styling');
  } else {
    console.log('CSS file not found');
  }
}

// Function to update the HTML files to use the hero image
function updateHTMLFiles() {
  console.log('Updating HTML files to use the hero image...');
  
  // Get all HTML files
  const htmlFiles = [
    'index.html',
    'pages/about.html',
    'pages/features.html',
    'pages/octavia.html',
    'pages/subscribe.html'
  ];
  
  for (const htmlFile of htmlFiles) {
    const filePath = path.join(__dirname, htmlFile);
    
    if (fs.existsSync(filePath)) {
      console.log(`Updating ${htmlFile}...`);
      
      // Read the HTML file
      const html = fs.readFileSync(filePath, 'utf8');
      const $ = cheerio.load(html);
      
      // Update the hero section if it exists
      if ($('.hero, .hero-section, #hero').length) {
        $('.hero, .hero-section, #hero').addClass('hero').attr('style', '');
        
        // Make sure the hero content is properly structured
        if ($('.hero-content').length === 0) {
          $('.hero').wrapInner('<div class="hero-content"></div>');
        }
      }
      
      // Write the updated HTML
      fs.writeFileSync(filePath, $.html());
    }
  }
  
  console.log('HTML files updated to use the hero image');
}

// Function to update the Octavia page specifically
function updateOctaviaPage() {
  console.log('Updating Octavia page with blue lips image...');
  
  const octaviaFilePath = path.join(__dirname, 'pages', 'octavia.html');
  
  if (fs.existsSync(octaviaFilePath)) {
    const html = fs.readFileSync(octaviaFilePath, 'utf8');
    const $ = cheerio.load(html);
    
    // Add a special section highlighting the blue lips
    const blueSection = `
    <section class="blue-lipstick-feature">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">
            <h2>The Signature Blue Lipstick</h2>
            <p class="lead">Octavia's iconic blue lipstick is more than a style choice—it's a statement of bold authenticity and the visual embodiment of our brand philosophy.</p>
          </div>
        </div>
      </div>
    </section>
    `;
    
    // Add the section after the first section
    $('section:first').after(blueSection);
    
    // Write the updated HTML
    fs.writeFileSync(octaviaFilePath, $.html());
    console.log('Updated Octavia page with blue lips feature section');
  } else {
    console.log('Octavia page not found');
  }
}

// Main function to update the hero image
async function updateHeroImage() {
  try {
    console.log('Starting hero image update...');
    
    // Update the CSS
    updateHeroImageInCSS();
    
    // Update the HTML files
    updateHTMLFiles();
    
    // Update the Octavia page specifically
    updateOctaviaPage();
    
    console.log('Hero image update completed successfully!');
  } catch (error) {
    console.error('Error updating hero image:', error);
  }
}

// Run the update
updateHeroImage();
